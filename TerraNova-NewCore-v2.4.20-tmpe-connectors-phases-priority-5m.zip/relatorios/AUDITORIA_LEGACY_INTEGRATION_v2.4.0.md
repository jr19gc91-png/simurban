# AUDITORIA LEGACY INTEGRATION v2.4.0

Projeto: Terra Nova / SIMURB NewCore
Entrega: `TerraNova-NewCore-v2.4.0-legacy-systems-integration.zip`
Base NewCore: `TerraNova-NewCore-v2.3.21-controls-road-grid-ui-fix.zip`
Referencia antiga: `simurban modular.zip`

## Conclusao

O NewCore foi mantido como casca/renderer moderno e passou a concentrar a jogabilidade principal do SIMURB antigo por integracao modular: controles classicos, layout classico adaptado, grade RCI vinculada a vias, trafego por faixa/sentido, transporte publico, trilhos, economia, eventos/incidentes, save/load e HUD operacional.

A iluminacao antiga NAO foi integrada. A v2.4.0 possui uma nova atmosfera NewCore propria, com ciclo dia/noite cinematografico, clima dinamico, ceu procedural, sol visivel, lua, nuvens e chuva. Esse sistema foi implementado em `src/map/AtmosphereSystem.js`, sem importar sky/lighting/atmos do jogo antigo.

## Arquivos alterados

- `README.md`
- `index.html`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`
- `styles/newcore.css`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `src/game/GameShell.js`
- `src/systems/InputController.js`
- `src/systems/ZoningSystem.js`
- `src/systems/VehicleSystem.js`
- `src/systems/SimulationSystem.js`
- `src/roads/RoadRenderer.js`
- `src/ui/InfoPanels.js`
- `src/ui/UISystem.js`

## Arquivos criados

- `src/legacy/LegacyConstants.js`
- `src/systems/EventSystem.js`
- `src/map/AtmosphereSystem.js`
- `relatorios/AUDITORIA_LEGACY_INTEGRATION_v2.4.0.md`
- `relatorios/RELATORIO_v2.4.0_legacy_systems_integration.md`

## Sistemas antigos integrados/adaptados

- Layout classico de dock lateral e paineis de dados, conectado ao estado real do NewCore.
- Fluxo separado Novo Jogo -> Gerador -> Cidade, sem misturar UI do gerador com HUD da cidade.
- Controles classicos de camera/ferramentas: WASD/setas, Q/E, PageUp/PageDown ja existentes, hotkeys numericas de ferramentas, Escape e clique direito para cancelar.
- Estradas com rua, avenida, mao unica, curva/reta, niveis, upgrade, cruzamentos T/X por RoadCore modular.
- Grade RCI de 20 m com ate 4 fileiras por via zoneavel, inspirada no antigo.
- Pintura de zoneamento residencial, comercial e industrial sobre grade viaria.
- Frente/lote orientado para a via por `lotRotation`, `roadHeading` e `roadDistance`.
- Trafego por grafo viario respeitando mao unica, classe de faixa, faixa de onibus/mista/servico e controles TMPE.
- Onibus com paradas, linhas, auto-linha, frota e telemetria.
- Trilhos duplos, estacoes, linha ferroviaria, trem e telemetria.
- Economia/RCI com demanda, populacao, empregos, impostos, custos, passageiros/h, congestionamento e historico.
- Save/export JSON e import/load com round-trip validado.
- Eventos/incidentes leves derivados do comportamento antigo, reduzindo velocidade por segmento afetado.
- Atmosfera NewCore v2.4.0 propria: clima dinamico, dia/noite, sol/lua/nuvens/chuva, sem assets externos.

## Sistemas ignorados

- Iluminacao antiga.
- Sky/atmos/fog/tone mapping antigo.
- Setup de renderer/shadows antigo.
- `game.js` antigo como monolito.
- `game.original.js` inteiro.
- Assets PNG externos obrigatorios.
- Dependencias de CDN/internet.

## Confirmacoes de proibicoes

- `src/main.js` nao foi substituido por `game.js` antigo.
- Nenhum `game.js` monolitico foi criado na raiz.
- `MapGenerator.js` foi mantido.
- Tela inicial, gerador e HUD da cidade foram preservados.
- `vendor/three.module.js` foi preservado.
- Launchers Windows e Bazzite/Linux foram preservados e atualizados para v2.4.0.
- Relatorios foram salvos dentro de `/relatorios`, nao na raiz.
- Iluminacao antiga NAO foi integrada.

## Validacao executada

- `node_repl` / `vm.SourceTextModule`: parse de todos os modulos `src/*.js` sem erro.
- Auditoria de tamanho: maior modulo em `src/` ficou em `src/systems/RoadSystem.js` com 1141 linhas; nenhum monolito `game.js` novo.
- Busca estatica: sem import de `game.original.js`, sem import do antigo modular e sem transplante bruto.
- Smoke Playwright/Chrome headless:
  - tela inicial visivel;
  - gerador visivel com topbar escondida;
  - cidade com HUD separada;
  - construcao de ruas, avenida, mao unica, curva e cruzamentos;
  - zoneamento R/C/I;
  - predios surgindo;
  - veiculos, onibus e trem ativos;
  - TMPE com semaforo;
  - eventos preparados;
  - save/load JSON round-trip;
  - clima/HUD de clima;
  - atmosfera com grupo renderizado;
  - sem `pageerror` ou `console.error`.
- Pixel check por screenshot PNG:
  - captura `1366x768`;
  - media RGB da cena: `[20.9, 26.89, 32.63]`;
  - crop da cena nao ficou em branco: extrema RGB `((5,99),(8,105),(10,110))`.

## Validacoes bloqueadas pelo ambiente

- `node tools/check-js.mjs`, `node tools/audit-modules.mjs` e `node tools/smoke-newcore.mjs`: `node` nao esta no PATH do PowerShell. Foi usado `node_repl` com parser ESM e Playwright como equivalente.
- `bash -n iniciar-terra-nova-bazzite.sh`: `bash` nao esta no PATH; WSL existe apenas como stub sem distro funcional. O arquivo foi inspecionado e atualizado estaticamente.
- `git status`: `git` nao esta no PATH.

## Bugs conhecidos

- QA manual completa de 1920x1080 e 1366x768 deve ser refeita por humano apos extrair o ZIP final, porque FPS e conforto visual dependem da GPU/navegador local.
- O sistema de clima e incidentes e deterministico por seed/dia/periodo, mas ainda nao tem UI dedicada para forcar clima especifico.
- Tunel/nivel negativo depende do suporte existente de niveis PageUp/PageDown/RoadCore; o smoke automatizado validou rede/veiculos, mas nao fez roteiro manual completo de tunel.

## Proximos passos recomendados

- Rodar QA manual completo do checklist abaixo em maquina alvo.
- Adicionar painel de debug opcional para forcar clima: limpo, bruma, nublado, chuva, tempestade.
- Expandir incidentes com resposta de servicos e custo operacional.
- Ampliar testes automatizados para PageUp/PageDown, elevado/tunel e paradas criadas manualmente.
