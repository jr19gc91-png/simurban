# AUDITORIA LEGACY PARITY LIGHTING/TOOLS v2.4.1

Entrega prevista: `TerraNova-NewCore-v2.4.1-legacy-parity-lighting-tools-hotfix.zip`

## Criterios verificados

- O jogo abre na tela inicial: validado por browser smoke.
- Gerador aparece separado da HUD: validado por browser smoke.
- Cidade aparece com HUD separada: validado por browser smoke.
- Iluminacao antiga nao foi integrada: validado por auditoria de arquivos alterados.
- Estradas continuam construindo: codigo preservado; parse JS passou.
- Zoneamento continua funcional: grid/loteamento preservados e corrigidos.
- Veiculos nao foram alterados para contramao; grafo/direcao existente preservados.
- Onibus/trens preservados; Sandbox controla trafego/linhas de teste.
- Economia/simulacao preservadas; HUD segue atualizando.
- Save/load JSON preservado; schema atualizado para `newcore-save-v2.4.1`.
- Modulos continuam abaixo de 1200 linhas: auditoria passou, maximo 1160.
- Erro fatal de console no smoke 1366x768: nenhum.
- Launchers Windows e Bazzite preservados e atualizados.
- Relatorios salvos em `/relatorios`.

## Pontos tecnicos auditados

- `src/map/AtmosphereSystem.js`: ceu agora segue a camera; exposicao e fog foram clareados; sol/lua/nuvens/chuva seguem sistema NewCore.
- `src/systems/ZoningSystem.js`: rotacao da grade corrigida para eixo de plano; folga em nos aumentada; lados de zona respeitados.
- `src/roads/RoadMarkings.js`: marcacoes/overlays recortados perto de cruzamentos.
- `src/systems/VehicleSystem.js`: modo Sandbox/Simulacao controla fallback de trafego; movimento visual usa multiplicador central.
- `src/game/GameShell.js`: modo de jogo e opcoes antigas de estrada entram no estado real.
- `src/ui/UISystem.js` e `index.html`: submenus de estrada expandidos com opcoes do antigo.

## Comandos executados

```powershell
C:\Users\User\AppData\Local\OpenAI\Codex\bin\5b9024f90663758b\node.exe tools\check-js.mjs
C:\Users\User\AppData\Local\OpenAI\Codex\bin\5b9024f90663758b\node.exe tools\audit-modules.mjs
```

Smoke em navegador embutido:

```text
http://127.0.0.1:8131/?cache=v241-browser-smoke-2
```

Resultado do smoke:

```json
{
  "startVisible": "flex",
  "generatorDisplay": "block",
  "cityGeneratorDisplay": "none",
  "cityHudDisplay": "grid",
  "roadPresetCount": 9,
  "roadToggleCount": 4,
  "speedButtons": ["1", "2", "3", "4", "5"],
  "fatalLogs": []
}
```

## Riscos residuais

- O smoke Playwright do projeto nao rodou porque Playwright nao esta instalado.
- A tentativa de viewport 1920x1080 pelo navegador embutido derrubou a conexao da ferramenta; recomendada verificacao manual em monitor 1920x1080.
- `bash -n` do launcher Bazzite nao foi concluido porque este Windows nao tem bash no PATH e o WSL disponivel nao tem distribuicao configurada.
- Ainda ha sistemas do antigo que podem ganhar mais detalhe fino em rodadas futuras, especialmente transporte avancado, paineis de economia e ferramentas de terreno.

## Conclusao

A v2.4.1 corrige defeitos comparativos diretos apontados pelo usuario sem trocar a arquitetura NewCore, sem importar iluminacao antiga e sem transformar o projeto em monolito.
