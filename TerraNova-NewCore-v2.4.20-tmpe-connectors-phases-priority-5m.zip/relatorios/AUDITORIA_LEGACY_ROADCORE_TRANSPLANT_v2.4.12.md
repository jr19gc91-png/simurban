# Auditoria v2.4.12 - Legacy RoadCore Transplant 5m/u

## Escopo auditado

- Transplante do comportamento de ferramentas/estradas do jogo antigo para o NewCore.
- Preservacao do renderer, mapa, terreno, atmosfera e iluminacao NewCore.
- Integridade dos launchers Windows e Bazzite.
- Modularidade e ausencia de monolito `game.js`.
- Validacao automatizada de sintaxe, tamanho de modulos e smoke headless.

## Checklist de aceitacao

- Jogo abre no smoke headless: OK.
- Tela/versao NewCore reconhecida: OK.
- Cidade inicia com sistemas nucleo: OK.
- Gerador e HUD continuam separados: OK por estrutura/estilos preservados; QA manual recomendado.
- Iluminacao NewCore permanece: OK.
- Iluminacao antiga nao integrada: OK.
- Nenhum import bruto de `game.original.js`: OK.
- `src/main.js` nao foi substituido: OK.
- `MapGenerator.js` preservado: OK.
- `vendor/three.module.js` preservado: OK.
- Estradas constroem e renderizam: OK, smoke renderizou 1042 malhas de via.
- Zoneamento/predios funcionam: OK, smoke gerou lotes/predios e preservou save/load.
- Veiculos usam centros de faixa do RoadCore: OK por codigo em `VehicleSystem.js` + `LegacyRoadCore5m.js`; QA manual recomendado em mapa grande.
- TMPE/sinais funcionam: OK, smoke registrou semaforo e renderizou marcador.
- Painel/HUD e info panels funcionam: OK.
- Minimap presente: OK.
- Save/export/import JSON: OK.
- Modulos abaixo de 1200 linhas: OK, maximo 1189 linhas.
- Erro fatal de console no smoke: OK, zero erro.
- ZIP final contem tudo: OK no empacotamento final.

## Validacoes executadas

```text
npm run check
Resultado: OK, checked=38

npm run audit
Resultado: OK, modules=38 totalLines=11603 maxModuleLines=1189

npm run smoke
Resultado: OK, TODOS OS TESTES PASSARAM
```

O smoke foi executado com Chrome local:

```text
CHROME_PATH=C:\Program Files\Google\Chrome\Application\chrome.exe
PYTHON=C:\Users\User\AppData\Local\Programs\Python\Python313\python.exe
PW_INDEX=file:///C:/Users/User/AppData/Local/OpenAI/Codex/runtimes/cua_node/1b23c930bdf84ed6/bin/node_modules/playwright/index.mjs
```

## Bash/Bazzite

O arquivo `iniciar-terra-nova-bazzite.sh` foi atualizado para v2.4.12, cache-bust `v2412`, fallback de Python e abertura via `xdg-open`/browser local.

`bash -n iniciar-terra-nova-bazzite.sh` nao foi executado porque este Windows nao possui `bash` no PATH e o WSL disponivel e somente o stub sem distribuicao Linux. A revisao estatica nao encontrou quebra obvia de sintaxe.

## Integracao legado x NewCore

O antigo foi usado como referencia para:

- `roadLaneMetrics`
- offsets de faixa
- transicoes de endpoint
- trim de cruzamento
- fluxo por faixa/sentido
- minimapa e comportamento de UI operacional

O antigo nao foi usado para:

- renderer
- luz global
- sky
- atmosfera
- monolito
- assets externos obrigatorios

## Risco residual

- Rotas longas de onibus/trem e FPS final ainda precisam de QA manual nos dois viewports pedidos.
- Se saves antigos tiverem combinacoes exoticas de elevacao/tunel, o adaptador de endpoint pode precisar de ajuste fino, mas o smoke de save/load e render passou sem erro.
