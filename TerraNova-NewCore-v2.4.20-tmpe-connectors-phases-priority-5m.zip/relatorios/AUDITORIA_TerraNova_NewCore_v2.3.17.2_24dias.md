# Auditoria 100% — TerraNova NewCore v2.3.17.2

Data: 2026-06-29
Base auditada: `TerraNova-NewCore-v2.3.17.2-build-click-fix.zip`

## Veredito executivo

O projeto não está ruim, mas a direção recente virou híbrida: ambiente moderno + UI parcialmente clássica + ferramentas parcialmente adaptadas. O principal risco é continuar empilhando patches sem consolidar contratos.

**Estado atual estimado para finalizar em 24 dias:**
- Motor/base NewCore: 65%
- UI clássica correta: 55%
- Ferramentas construção: 58%
- Estradas/render/interseções: 45%
- Tráfego/faixas: 35%
- Trilhos: 45%
- Zoneamento/construções: 50%
- Save/load/launchers: 75%
- Polimento final/QA: 25%

Conclusão: em 24 dias dá para fechar um alpha jogável forte, mas não dá para prometer um city builder completo estilo Cities + TMPE 100%. Precisa congelar escopo e priorizar.

## Validação técnica rodada

```txt
bash -n iniciar-terra-nova-bazzite.sh → OK
node tools/check-js.mjs → checked=34
node tools/audit-modules.mjs → modules=34 / totalLines=9177 / maxModuleLines=1153
```

Smoke Playwright não foi validado neste ambiente.

## Estrutura atual

Arquivos principais:
- `src/game/GameShell.js` — orquestra estado, fluxo e sistemas.
- `src/game/GameState.js` — schema/save.
- `src/map/MapGenerator.js` — terreno moderno e câmera.
- `src/systems/InputController.js` — clique, preview, ferramentas.
- `src/systems/RoadSystem.js` — RoadCore atual.
- `src/roads/RoadRenderer.js` — render de via.
- `src/roads/RoadIntersections.js` — cruzamentos.
- `src/roads/RoadMarkings.js` — marcações.
- `src/systems/VehicleSystem.js` — tráfego/veículos.
- `src/systems/RailSystem.js` — trilhos/estações/linhas.
- `src/ui/UISystem.js` — UI e submenus.
- `styles/newcore.css` — visual da UI.

## O que está correto ou perto do antigo

### Fluxo
- Existe tela inicial.
- Existe gerador separado.
- Existe modo cidade.
- A intenção `Novo Jogo → Gerador → Cidade` já está no código.

### Interface
- Topbar existe.
- Barra lateral esquerda existe.
- Barra inferior existe.
- Ferramentas principais estão na barra inferior.
- Dashboard lateral esquerdo existe com Relatórios/Linhas/Economia/Tráfego.

### Ferramentas
- Estradas: terra, rua, avenida, mão única.
- Trilhos: simples/duplo, trem/VLT/metrô.
- Nível por PageUp/PageDown.
- TMPE por faixa começou com `laneClasses[]`.

### Ambiente
- Terreno/luz/água/vegetação modernos preservados.

## O que ainda NÃO está igual ao antigo

### UI
1. CSS ainda tem herança conflitante de versões anteriores.
2. Existem seletores antigos de painel direito (`right`, `.tool-panel`, `.tmpe-panel`, `.tn-info-panel`, minimap etc.) ainda vivos no CSS. Mesmo que alguns sejam sobrescritos depois, isso aumenta risco de regressão.
3. Submenu de ferramenta está acima da barra inferior, mas ainda parece um painel grande moderno, não uma janela compacta clássica.
4. Topbar ainda tem status demais e não tem clima real/visual final.
5. Lateral esquerda é dashboard, mas ainda precisa de layout final igual ao antigo.

### Estradas
1. Interseções ainda são meshes compostos, não uma peça final perfeita.
2. Continuidade das faixas dentro de T/X/Y ainda não está fechada.
3. Avenida tem canteiro visual, mas não é canteiro modular completo.
4. Mão única existe, mas renderização e setas ainda precisam padrão final.
5. Calçada/curb ainda não acompanha todas as geometrias perfeitamente.
6. Rotatórias ainda não existem.

### Tráfego
1. Veículos têm preferência por faixa, mas não LaneSystem robusto.
2. Não há conversão por faixa completa.
3. Troca de faixa é aproximada.
4. Não há semáforo completo por fase/tempo.
5. Não há conectores faixa-a-faixa reais.

### Trilhos
1. Render melhorou, mas não está final.
2. Não há AMV/chave ferroviária.
3. Cruzamento ferroviário/passagem de nível não está consolidado.
4. Metrô/VLT/Trem ainda são diferenciações parciais.

## Bugs/riscos encontrados

### Alto risco
- `styles/newcore.css` está acumulativo e contraditório. Tem muitas regras antigas sobrescritas por regras novas. Precisa limpar.
- UI e ferramentas ainda estão acopladas em `UISystem.js`, que cresce como centralizador.
- `RoadSystem.js` está no limite alto de tamanho e concentra lógica demais.
- Interseções ainda são ponto crítico visual.

### Médio risco
- O clique foi corrigido para `pointerup`, mas precisa teste visual real em relevo/árvores/rochas.
- Save/load existe, mas a migração entre versões ainda é frágil.
- Launchers foram corrigidos, mas precisam teste em Windows/Bazzite real.

### Baixo risco
- Sintaxe JS OK.
- Módulos abaixo de 1200 linhas.
- Estrutura geral modular aceitável.

## Plano realista de 24 dias

### Semana 1 — Congelar base e UI clássica
Objetivo: parar retrabalho.

1. Limpar CSS legado e remover painel direito/minimap/docks do modo cidade.
2. Reestruturar submenus das ferramentas acima da bottombar.
3. Topbar só status.
4. Leftbar só dashboards.
5. Ferramentas só bottombar.
6. Criar contrato `ClassicUIAdapter`.

Entrega: UI clássica limpa e estável.

### Semana 2 — Estradas e construção
Objetivo: construção parecer jogo de verdade.

1. Corrigir preview de estrada/trilho.
2. Garantir clique confiável em relevo.
3. Corrigir curvas/retas.
4. Estrada terra/rua/avenida/mão única com render final.
5. Interseções T/X/Y sem rachadura.
6. Limpeza de obstáculos no corredor.

Entrega: ferramenta de vias confiável.

### Semana 3 — Tráfego/faixas + trilhos
Objetivo: transporte começar a funcionar.

1. LaneSystem mínimo real.
2. Veículos seguindo faixa/sentido correto.
3. Conversões básicas por faixa.
4. TMPE por faixa visível e aplicável.
5. Trilho simples/duplo/VLT/metrô/trem com render final mínimo.
6. Estações e linhas funcionando sem regressão.

Entrega: base de simulação urbana jogável.

### Dias 22–24 — QA, performance e pacote final
Objetivo: parar de quebrar.

1. Teste em 1366×768 e 1920×1080.
2. Teste Windows `.bat`.
3. Teste Bazzite `.sh`.
4. Save/load/import/export.
5. Relatório final.
6. Último ZIP candidato a alpha.

## Prioridade brutal

O que NÃO fazer agora:
- Novos assets grandes.
- Economia profunda.
- 100 veículos.
- TMPE completo demais.
- Rotatória se as interseções T/X/Y ainda não estiverem boas.
- Refazer ambiente visual.

O que fazer agora:
1. UI clássica limpa.
2. Estradas corretas.
3. Clique/construção confiável.
4. Interseções decentes.
5. Veículos andando certo.

## Próxima implementação recomendada

Criar `v2.3.18-stability-ui-road-audit-fix` com:
- limpeza CSS forte;
- remoção real de painéis/docks direitos no modo cidade;
- submenu inferior compacto e sem scroll gigante;
- botão de ferramenta sempre clicável;
- tool state mais previsível;
- estrada/trilho com clique auditado;
- relatório de QA.

## Resumo direto

A base é recuperável. O erro foi avançar por patch visual incremental sem congelar o contrato antigo da UI/ferramenta. Agora a rota certa é consolidar antes de adicionar qualquer feature.
