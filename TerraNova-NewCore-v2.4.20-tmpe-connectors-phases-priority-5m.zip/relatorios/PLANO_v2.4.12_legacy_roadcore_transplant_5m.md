# Plano v2.4.12 - Legacy RoadCore Transplant 5m

## Base
- Atual: TerraNova-NewCore-v2.4.11-visual-ui-crossing-lanes-5m.
- Legado: simurban modular, especialmente RoadCore, marcacoes, cruzamentos, minimapa, lane following e UI operacional.
- Escala oficial mantida: 1 unidade = 5 metros.

## Estrategia
- Manter o NewCore como casca moderna: mapa, terreno, atmosfera, renderer, fluxo de tela inicial e gerador.
- Reaproveitar comportamento legado por adaptacao modular, sem colar `game.js` inteiro.
- Centralizar metricas de vias/faixas em helper 5m para evitar divergencia entre render, trafego e zoneamento.

## Ordem tecnica
1. Corrigir visibilidade e controles do minimapa no modo cidade.
2. Criar adaptador de RoadCore legado em escala 5m/u para largura, faixas, offsets, mediana, acostamento, rampas e limpeza de nos.
3. Ligar renderer, marcacoes e cruzamentos ao adaptador, preservando o terreno/iluminacao NewCore.
4. Recalibrar elevados/rampas, pilares e sombras para escala 5m/u.
5. Recalibrar trilhos, dormentes e plataformas para nao excederem a largura de avenida.
6. Ajustar veiculos para usar centro real de faixa, inclusive em curvas.
7. Ajustar zoneamento para nao invadir vias, cruzamentos, calcadas, medianas, rampas ou elevados, e mostrar grid apenas nas ferramentas adequadas.
8. Auditar artefatos de terreno e remover props/decal visualmente quebrados quando identificados.

## Validacao prevista
- `npm run check`
- `npm run audit`
- `bash -n iniciar-terra-nova-bazzite.sh`
- Smoke test local quando as dependencias estiverem disponiveis.
- Inspecao manual/codigo para minimapa, curvas, cruzamentos, elevados, trilhos, veiculos e zoneamento.
