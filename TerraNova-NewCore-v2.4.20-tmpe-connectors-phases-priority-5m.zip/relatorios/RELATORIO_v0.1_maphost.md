# Relatório — TerraNova-NewCore v0.1 MapHost

## Escopo executado

Rodada 1 iniciada com a nova arquitetura: o gerador de mapas passa a ser o host do novo jogo.

## Implementado

- Modularização inicial do gerador em `src/map/MapGenerator.js`.
- Importação local de Three.js e OrbitControls.
- Criação de `MapAdapter` para expor terreno, altura, inclinação, água e área construível.
- Criação de `GameShell` com grupos próprios para construção, estradas, zonas, construções, veículos e debug.
- Criação de `GameState` com schema de save novo.
- Criação de UI NewCore mínima com topbar/bottombar.
- Save/load JSON inicial.
- Scaffold para `AssetRegistry` e pacotes separados de construções 3D.

## Correção feita no gerador

O gerador referenciava `MAT.current` para linhas de correnteza, mas o material não estava definido no objeto de materiais. Foi criado material local para evitar quebra no rebuild dos rios.

## Não implementado ainda

- RoadCore real.
- Construção de estradas.
- Zoneamento funcional.
- Simulação/economia real.
- Render de construções novas.
- Veículos/trânsito/transporte público.

## Próxima rodada sugerida

`v0.2-roadcore`: adaptar ferramentas de construção e RoadCore usando `MapAdapter`.
