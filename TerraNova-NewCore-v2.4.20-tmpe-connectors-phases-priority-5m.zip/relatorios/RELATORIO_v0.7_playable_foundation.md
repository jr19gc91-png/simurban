# Relatório — Terra Nova NewCore v0.8 RoadCore Alpha

## Decisão de arquitetura

O projeto deixou de tentar implantar o novo gerador dentro do jogo antigo. O gerador novo agora é o host principal do jogo. O pacote antigo modularizado foi mantido em `src/legacy/source` como referência/mina de sistemas, mas não é carregado diretamente no runtime.

## Rodadas consolidadas nesta entrega

### Rodada 1 — MapHost
- Gerador modularizado.
- Three.js local.
- GameShell / GameState / MapAdapter.

### Rodada 2 — RoadCore inicial
- Ferramenta de estrada por nós/segmentos.
- Preview de construção.
- Snap em nós existentes.
- Render de asfalto, calçadas e marcações.
- Demolição de vias.
- Save/load de nós e segmentos.

### Rodada 3 — Zoneamento
- Zoneamento residencial, comercial e industrial.
- Lotes gerados pelos lados da via.
- Validação por terreno construível, água e inclinação.
- Render visual dos lotes.

### Rodada 4 — Construções
- Starter pack procedural 3D.
- Casas, comércios e galpões gerados por zona.
- Variações automáticas de cor, altura, telhado e detalhe.
- Estrutura preservada para packs 3D externos.

### Rodada 5 — Simulação
- Tempo de jogo.
- Dinheiro.
- População.
- Empregos.
- Passageiros/hora.
- Custos básicos de vias, trilhos e transporte.

### Rodada 6 — Transporte público
- Veículos automáticos em vias.
- Linha de ônibus automática quando a cidade possui base construída.
- Receita simplificada por passageiros/hora.

### Rodada 7 — Trilhos
- Ferramenta de trilhos por nós/segmentos.
- Render de leito, trilhos e dormentes.
- Trem automático inicial quando há trilho suficiente.

## Limitações conhecidas

- RoadCore ainda é básico: não há curvas Bézier, cruzamentos complexos, elevados/túneis completos ou faixas editáveis por segmento.
- Zoneamento ainda é retangular simples e precisa refinamento visual em curvas futuras.
- Veículos usam rotas simplificadas por segmentos existentes, ainda sem pathfinding completo.
- Transporte público cria linhas automáticas iniciais; editor manual de linhas fica para próxima rodada.
- Construções starter são procedurais simples. O pipeline definitivo de assets 3D separados deve substituir esse pack.
- Chromium headless no ambiente de teste ficou pesado para screenshot completo por causa da geração WebGL; validação de sintaxe passou com `npm run check`.

## Validação realizada

```bash
npm run check
```

Resultado: todos os arquivos JS passaram no `node --check`.

## Próximo passo recomendado

Criar a primeira rodada de assets 3D externos para o NewCore:

1. Residencial baixa densidade BR — 20 a 50 construções starter.
2. Comercial baixa densidade BR.
3. Industrial leve BR.

Depois, refinar RoadCore:

- curvas suaves;
- cruzamentos reais;
- elevados/túneis;
- upgrade de segmento;
- faixas por sentido;
- zoneamento em curvas sem sobra.
