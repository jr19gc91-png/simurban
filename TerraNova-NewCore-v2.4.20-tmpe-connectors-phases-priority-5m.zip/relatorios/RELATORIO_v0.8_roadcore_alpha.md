# Relatório — Terra Nova NewCore v0.8 RoadCore Alpha

## Objetivo da rodada

Avançar a fundação v0.7 para a primeira rodada real de RoadCore no NewCore, mantendo o novo gerador de mapas como host principal do jogo e mantendo o pacote antigo apenas como fonte legacy de referência.

## Inicializadores atualizados

- `iniciar-terra-nova-windows.bat` agora abre o navegador automaticamente em `http://127.0.0.1:8123/` e mantém o servidor preso ao endereço local `127.0.0.1`.
- `iniciar-terra-nova-bazzite.sh` faz o mesmo usando `xdg-open`/`gio` quando disponível.
- A mensagem `Serving HTTP on 127.0.0.1 port 8123` é comportamento esperado: o terminal fica aberto porque ele é o servidor local do jogo.

## RoadCore Alpha

Implementado no `src/systems/RoadSystem.js`:

- Snap em nós existentes.
- Snap em segmento existente.
- Ao clicar em um segmento, a via antiga é dividida e um novo nó é criado no ponto de encaixe.
- Construção de uma nova via cruzando outra via no mesmo nível divide automaticamente a rede e cria cruzamento T/+.
- Segmentos em níveis diferentes não são divididos automaticamente, preparando a base para elevados/túneis.
- Bloqueio básico de construção em água para vias no solo.
- Bloqueio básico de construção em inclinação/grade extrema para vias no solo.
- Estradas elevadas iniciais podem passar sobre água/terreno ruim, ainda como base visual simples.
- Render inicial de placa/pad de interseção em nós com duas ou mais conexões.

## UI/Controles

- Adicionado slider de nível da via no painel de construção.
- PageUp/PageDown com a ferramenta Estrada ativa altera o nível da próxima via.
- Estado de opções de construção (`buildOptions`) agora entra no save/load JSON.

## Limites conhecidos

- Curvas suaves ainda não foram implementadas; a rede ainda é segmentada por linhas retas entre nós.
- Elevados/túneis ainda não possuem pilares, rampas, portais ou modo subterrâneo real.
- Interseções ainda são renderizadas como pads simples, sem semáforos/faixas de pedestres detalhadas.
- Zoneamento ainda é simples e pode precisar de limpeza refinada ao dividir vias já zoneadas.
- Rodovias, avenidas com canteiro, mão única e classes de faixa ficam para as próximas etapas.

## Validação

Executado:

```bash
npm run check
```

Resultado: sem erro de sintaxe nos módulos JavaScript.

## Próxima etapa recomendada

`v0.9-road-types`: tipos de via, mão única, avenida com canteiro, largura/faixas consistentes, melhor preview e preparação para rampas/elevados/túneis reais.
