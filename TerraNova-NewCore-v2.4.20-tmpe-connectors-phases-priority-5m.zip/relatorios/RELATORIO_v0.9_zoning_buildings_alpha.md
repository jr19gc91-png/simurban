# Terra Nova NewCore v0.9 — Zoning + Buildings Alpha

## Objetivo da rodada

Avançar a base NewCore da v0.8 para uma fundação melhor de zoneamento e construções, mantendo o novo gerador como host principal do jogo.

## Alterações principais

- Zoneamento agora usa perfis por zona:
  - residencial: lotes menores e declive moderado;
  - comercial: lotes médios e mais rígidos;
  - industrial: lotes maiores e filtro de terreno mais forte.
- Lotes agora evitam:
  - água;
  - inclinação forte;
  - variação vertical exagerada dentro do lote;
  - cruzamentos/nós próximos;
  - estradas vizinhas;
  - sobreposição com lotes existentes.
- Render de lote recebeu:
  - base/fundação;
  - driveway/acesso frontal;
  - borda mais limpa.
- `BuildingSystem` foi refeito para aceitar melhor o pipeline de packs separados.
- Starter pack subiu de 12 para 24 definições lógicas.
- Construções starter ficaram mais variadas:
  - casas com muros, garagens, lajes, telhados e props;
  - comércios com letreiro, vitrine, marquise e rooftop props;
  - indústrias com galpão, doca, chaminé, tanque e pátio.
- UI mostra contagem de lotes e construções no painel de ferramentas.
- `MapAdapter` ganhou `isInsideWorld()` para sistemas urbanos validarem bordas do mapa.

## Arquivos alterados

- `src/systems/ZoningSystem.js`
- `src/systems/BuildingSystem.js`
- `src/assets/buildings/placeholderBuildingPack.js`
- `src/map/MapAdapter.js`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `src/ui/UISystem.js`
- `index.html`
- `styles/newcore.css`
- `docs/ASSET_PIPELINE_BUILDINGS.md`

## Validação

Executar:

```bash
npm run check
```

Também manter uso pelo inicializador:

- Windows: `iniciar-terra-nova-windows.bat`
- Bazzite/Linux: `./iniciar-terra-nova-bazzite.sh`

## Limitações conhecidas

- Construções ainda são procedural starter, não assets finais.
- Zoneamento ainda é por clique em segmento, sem pintura contínua por arraste.
- Ainda não há nivelamento real/terraforming de lote; há apenas fundação visual.
- RoadCore ainda precisa curva suave, upgrades, elevado/túnel visual completo e regras avançadas de faixas.
