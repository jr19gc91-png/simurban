# Terra Nova NewCore v1.0 — Road + Zoning Polish

## Objetivo da rodada

Avançar a fundação jogável criada sobre o novo gerador de mapas, sem voltar a usar o jogo antigo como base principal. O foco foi polir RoadCore alpha, zoneamento e fluxo de construção.

## Alterações principais

### RoadCore

- Adicionado modo `Melhorar via`.
- O upgrade aplica a configuração atual de faixas e velocidade ao segmento clicado.
- `RoadSystem` agora guarda velocidade padrão da próxima via.
- Segmentos novos herdam faixas, velocidade e nível configurados na UI.
- Adicionado `cleanupNetwork()` para remover segmentos inválidos e nós órfãos.

### Zoneamento

- Zoneamento agora aceita pintura por arraste.
- Adicionada seleção de lado: 2 lados, esquerdo ou direito.
- `ZoningSystem.paintAt()` permite pintar segmentos próximos sem depender só de clique único.
- `cleanupInvalidLots()` remove lotes órfãos quando a via desaparece, muda de nível ou fica inconsistente.
- Lotes continuam filtrando água, inclinação, variação de altura e limites do mapa.

### UI

- Versão atualizada para NewCore v1.0.
- Adicionado botão `Melhorar via`.
- Adicionado controle de velocidade da via: 30–120 km/h.
- Adicionados botões de lado do zoneamento.
- `.bat` e `.sh` mantidos atualizados para v1.0.

### Save/schema

- Schema atualizado para `newcore-save-v1.0`.
- `buildOptions` agora salva:
  - `roadLanes`
  - `roadElevation`
  - `roadSpeed`
  - `zoneSide`

## Arquivos relevantes alterados

- `index.html`
- `styles/newcore.css`
- `src/game/GameState.js`
- `src/game/GameShell.js`
- `src/systems/RoadSystem.js`
- `src/systems/ZoningSystem.js`
- `src/systems/InputController.js`
- `src/ui/UISystem.js`
- `src/map/MapGenerator.js`
- `src/assets/buildings/placeholderBuildingPack.js`
- `README.md`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`

## Validação

Executado:

```bash
npm run check
```

Resultado: sem erro de sintaxe nos módulos JS.

Também validado via servidor local em `127.0.0.1:8123`, confirmando resposta HTTP para `index.html` e módulos principais.

## Limitações conhecidas

- Curvas ainda são retas segmentadas.
- Interseções ainda são pads simples.
- Elevados/túneis ainda são alpha visual.
- Não houve validação manual visual completa no Chrome com WebGL nesta rodada.
- Construções ainda são starter pack procedural; packs 3D brasileiros definitivos entram depois.

## Próxima etapa recomendada

`v1.1-road-geometry`:

- curvas suaves;
- preview de curva;
- calçadas condicionais por zoneamento;
- elevado/túnel visual mais claro;
- cruzamentos mais bonitos;
- preparação para mão única/avenida/canteiro.
