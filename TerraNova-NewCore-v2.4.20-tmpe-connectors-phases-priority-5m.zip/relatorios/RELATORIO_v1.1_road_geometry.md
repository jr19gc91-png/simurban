# Relatório técnico — TerraNova-NewCore v1.1 Road Geometry

## Objetivo

Avançar a base NewCore depois da v1.0, focando no primeiro refinamento geométrico do RoadCore sem trocar a arquitetura principal. O novo gerador continua sendo o host do jogo; os sistemas antigos continuam como referência/legado, não como runtime principal.

## Alterações feitas

### RoadCore / geometria

- Adicionado controle de traçado da via: `smooth` e `straight`.
- O traçado `smooth` usa interpolação Hermite 2D baseada na continuidade dos nós.
- Segmentos isolados continuam retos.
- Sequências de vias com conexões simples começam a arredondar visualmente.
- Cruzamentos com grau maior preservam comportamento mais rígido para evitar deformações excessivas.
- Comprimento de segmento no grafo passou a usar amostragem da geometria visual.

### Preview de construção

- Preview de estrada agora respeita:
  - largura/faixas;
  - nível da estrada;
  - traçado reto/suave.

### Elevado alpha

- Vias com nível positivo recebem:
  - barreiras laterais;
  - pilares simples em intervalos ao longo do segmento.

### Túnel alpha

- Vias com nível negativo recebem:
  - portais escuros nas extremidades;
  - linha-guia azul translúcida sobre o terreno para indicar o trecho subterrâneo.

### Calçadas

- Calçadas renderizam apenas em via zoneável e nível 0.
- Elevados e túneis deixam de gerar calçada comum.

### UI

- Adicionado seletor de traçado:
  - suave;
  - reto.
- Painel de ajuda atualizado.
- HUD/título atualizado para v1.1.

### Save/schema

- Schema atualizado para `newcore-save-v1.1`.
- Segmentos novos passam a salvar `geometry`.

### Inicializadores

- `iniciar-terra-nova-windows.bat` atualizado para v1.1.
- `iniciar-terra-nova-bazzite.sh` atualizado para v1.1.

## Validação

Executado:

```bash
npm run check
```

Resultado: sem erro de sintaxe nos módulos JS.

Também validado que os arquivos principais existem e que a estrutura do pacote permanece compatível com servidor local em `127.0.0.1:8123`.

## Limitações conhecidas

- Curvas são suavização visual, não uma ferramenta de curva manual com ponto de controle.
- Interseções ainda são pads simples.
- Elevados e túneis são alpha visual; ainda não existe modo subterrâneo completo.
- RoadCore ainda não tem classes de faixa, setas, semáforos ou TMPE.

## Próxima etapa recomendada

v1.2-road-crossings-polish:

- faixas de pedestres;
- setas de direção;
- pads de interseção mais bonitos;
- preview visual para upgrade e demolição;
- modo subterrâneo inicial;
- início do sistema de classes de faixa.
