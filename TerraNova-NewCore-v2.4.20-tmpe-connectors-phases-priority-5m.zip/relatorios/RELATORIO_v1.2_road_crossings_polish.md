# Relatório Técnico — Terra Nova NewCore v1.2 Road Crossings Polish

## Objetivo da rodada

Avançar o RoadCore visual sem fugir do escopo raiz: construção por nós/segmentos, vias legíveis, zoneamento acoplado a vias e base limpa para simulação futura.

## Melhorias implementadas

### RoadCore / construção

- Adicionado controle inicial de direção da via: mão dupla ou mão única.
- Segmentos novos salvam `direction`.
- Upgrade de via agora aplica faixas, velocidade, traçado e direção.
- Ao dividir segmento existente, o novo nó herda o nível da via original, evitando bug de nível misturado ao fazer snap em via elevada/túnel.
- `cleanupNetwork()` agora:
  - remove segmentos inválidos;
  - remove segmentos curtos demais;
  - mescla nós duplicados por coordenada/nível;
  - remove duplicatas de segmentos no mesmo nível.

### Interseções

- Interseções agora são renderizadas por nível.
- Evita pad único misturando via térrea, elevada e subterrânea.
- Pads de interseção ficaram um pouco maiores e mais consistentes para T/+.

### Sinalização

- Adicionadas faixas de pedestres em interseções térreas zoneáveis.
- Adicionadas linhas de retenção antes das faixas de pedestres.
- Adicionadas setas de direção ao longo das vias.
- Em mão dupla, as setas são desenhadas em offsets opostos com direção invertida sem inverter a lateral, evitando artefato tipo losango do legado.
- Em mão única, a seta fica centralizada e aponta no sentido A→B do segmento.

### Preview e UX

- Ferramenta de upgrade agora mostra highlight verde no segmento sob o mouse.
- Ferramenta demolir agora mostra highlight vermelho no segmento sob o mouse.
- Preview de construção e highlight foram separados para reduzir conflito visual.

### Materiais

- Novos materiais compartilhados:
  - `crosswalk`;
  - `stopLine`;
  - `arrow`;
  - `upgradeHighlight`.

## Arquivos principais alterados

- `src/systems/RoadSystem.js`
- `src/systems/InputController.js`
- `src/game/GameShell.js`
- `src/game/GameState.js`
- `src/ui/UISystem.js`
- `src/utils/Materials.js`
- `index.html`
- `styles/newcore.css`
- `README.md`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`

## Validação

Executado:

```bash
npm run check
```

Resultado: sem erro de sintaxe nos módulos JS.

Também foi feita validação de servidor local com `python3 -m http.server` e `curl` em rotas principais.

## Limitações conhecidas

- Crosswalks ainda são visuais; pedestres/semáforos vêm depois.
- Mão única já salva direção e desenha seta, mas IA ainda não obedece direção.
- Classes de faixa ainda não foram implementadas.
- Interseções ainda não possuem geometria avançada de ilha/canteiro/raio urbano.
- Validação visual WebGL real ainda depende do Chrome do usuário.

## Próxima rodada recomendada

`v1.3-road-lane-classes-alpha`:

- começar permissões/classes de faixa;
- corredor de ônibus básico;
- estacionamento lateral visual;
- UI de inspeção/edição de segmento;
- preparar VehicleSystem para respeitar direção e permissões.
