# Relatório técnico — Terra Nova NewCore v1.3 Road Lane Classes Alpha

## Objetivo da rodada

Adicionar classes de faixa por segmento, começar permissões de uso viário e preparar a IA de veículos para respeitar direção e tipos de faixa, sem fugir do padrão do `.md` raiz: via modular, mão direita Brasil, classes de faixa e evolução incremental.

## Alterações principais

### RoadSystem

- Adicionado `defaultLaneClass`.
- Segmentos novos agora salvam `laneClass`.
- Upgrade de via passa a aplicar também a classe de faixa.
- Inspetor passa a mostrar classe da faixa.
- Adicionados helpers:
  - `isValidLaneClass()`;
  - `normalizeLaneClass()`;
  - `getLaneClassLabel()`;
  - `getAllowedVehicles()`.
- Grafo rodoviário agora respeita mão única:
  - `twoWay`: cria arestas A→B e B→A;
  - `oneWay`: cria apenas A→B.
- Render visual de overlays por classe:
  - ônibus;
  - emergência;
  - serviços;
  - mista;
  - ciclovia;
  - estacionamento.
- Estacionamento lateral ganhou carros estacionados simples.

### UI

- Adicionado painel de classe de faixa.
- Botões novos:
  - geral;
  - ônibus;
  - emergência;
  - serviço;
  - mista;
  - bike;
  - estacionamento.
- Estado ativo sincronizado com `buildOptions.roadLaneClass`.
- Label da classe atual exibida no painel.

### GameState / Save

- Schema atualizado para `newcore-save-v1.3`.
- `buildOptions.roadLaneClass` adicionado com padrão `general`.
- `legacyBridge.adaptedTargets` atualizado com as novas adaptações.

### VehicleSystem

- Ambient traffic filtra caminhos incompatíveis com carros.
- Ônibus filtra caminhos compatíveis com bus/mixed/general/service.
- Lateral dos veículos agora considera classe da faixa.
- Base preparada para IA de permissão por classe.

### Materiais

Novos materiais:

- `busLane`;
- `emergencyLane`;
- `serviceLane`;
- `mixedLane`;
- `bikeLane`;
- `parkingLane`.

### Inicializadores

- `iniciar-terra-nova-windows.bat` atualizado para v1.3.
- `iniciar-terra-nova-bazzite.sh` atualizado para v1.3.

## Validação

Executado:

```bash
npm run check
```

Resultado: sem erros de sintaxe nos arquivos JS.

Também foi mantida a estrutura de servidor local na porta 8123 via `127.0.0.1`.

## Limitações conhecidas

- A classe de faixa ainda é aplicada por segmento inteiro, não por faixa individual clicável.
- Ciclovia ainda é visual/preparatória; não há pedestres/bicicletas simulados.
- Estacionamento é visual e não afeta demanda/capacidade ainda.
- Permissões são base para IA, mas ainda não há roteamento completo origem/destino.
- Não foi feita validação visual manual no Chrome com WebGL nesta rodada.

## Próxima etapa recomendada

v1.4-vehicle-ai-alpha:

- rotas casa-trabalho mais coerentes;
- tráfego por segmento;
- congestionamento por via;
- veículos respeitando mão única e permissões com mais rigor;
- inspeção de segmento com contadores de tráfego.
