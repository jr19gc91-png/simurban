# Relatório técnico — Terra Nova NewCore v1.4 Vehicle AI Alpha

## Objetivo da rodada

Avançar da v1.3, onde as vias já tinham mão única e classes de faixa, para uma primeira IA veicular real: veículos deixando de ser apenas tráfego decorativo e passando a usar rotas por grafo, com origem/destino, permissões e congestionamento básico.

## Alterações principais

### 1. RoadSystem

- `getRoadGraph(vehicleType)` agora aceita tipo de veículo e filtra arestas incompatíveis.
- Grafo respeita direção da via:
  - `twoWay`: A → B e B → A;
  - `oneWay`: somente A → B.
- Adicionado Dijkstra simples em `findPath()`.
- Adicionado custo por velocidade da via e penalidade por classe de faixa.
- Adicionado `findVehicleRouteBetweenPoints(origin, destination, vehicleType)`.
- Adicionado `buildRouteFromEdges()` com amostras orientadas no sentido real da viagem.
- Rotas carregam `segmentIds` e `segmentBreaks`, preparando inspeção e métricas futuras.

### 2. VehicleSystem

- Reescrito para trabalhar com pool de rotas.
- Carros agora geram viagens entre construções residenciais e construções com empregos.
- Rotas são calculadas pelo RoadSystem, não por concatenação burra de segmentos.
- Veículos respeitam:
  - mão única;
  - classe da faixa;
  - velocidade do segmento;
  - congestionamento local.
- Congestionamento básico por carga de segmento.
- Veículos de serviço urbanos simples adicionados.
- Ônibus automático passa a usar rotas compatíveis com bus/mista/geral.
- Telemetria adicionada:
  - veículos ativos;
  - ônibus ativos;
  - trens ativos;
  - velocidade média;
  - congestionamento veicular.

### 3. SimulationSystem

- Passageiros/hora agora considera ônibus ativos.
- Congestionamento final usa o maior valor entre:
  - pressão estrutural de população/vias;
  - congestionamento veicular real medido pelo VehicleSystem.

### 4. UI/HUD

- HUD agora mostra:
  - veículos ativos;
  - congestionamento.
- Textos atualizados para v1.4.

### 5. Save/schema

- Schema atualizado para `newcore-save-v1.4`.
- Novos campos de simulação:
  - `vehicleCongestion`;
  - `trafficVehicles`;
  - `activeBuses`;
  - `activeTrains`;
  - `avgTrafficSpeed`.

### 6. Inicializadores

- `iniciar-terra-nova-windows.bat` atualizado para v1.4.
- `iniciar-terra-nova-bazzite.sh` atualizado para v1.4.

## Validação realizada

```bash
npm run check
```

Resultado: sem erro de sintaxe.

Também foi validado servidor HTTP local em porta alternativa durante QA, confirmando resposta de:

- `/`
- `/src/main.js`
- `/src/systems/VehicleSystem.js`
- `/src/systems/RoadSystem.js`

## Limitações conhecidas

- Ainda não há paradas de ônibus manuais.
- Linhas de ônibus ainda são automáticas.
- Congestionamento é alpha: mede carga por segmento, mas ainda não cria fila física completa em cruzamentos.
- Semáforos/prioridades ainda não entram nesta rodada.
- Veículos ainda não fazem escolha modal completa carro x transporte público.

## Próxima etapa recomendada

`v1.5-transit-alpha`:

- paradas de ônibus;
- criação de linhas por pontos;
- capacidade e lotação;
- receita por linha;
- painel de transporte;
- passageiros/hora mais conectado à rede real.
