# Relatório técnico — Terra Nova NewCore v1.5 Infra Render Polish

## Etapa

Etapa 6/10 do plano Alpha NewCore.

## Objetivo

Corrigir a leitura visual inicial de infraestrutura. A v1.4 já possuía lógica funcional de RoadCore, classes de faixa, IA veicular e trilhos, mas as estradas/trilhos ainda pareciam debug visual. Esta rodada priorizou renderização de vias e trilhos sem quebrar a arquitetura do novo gerador como host principal.

## Arquivos principais alterados

- `src/utils/Materials.js`
- `src/systems/RoadSystem.js`
- `src/systems/RailSystem.js`
- `src/game/GameState.js`
- `src/map/MapGenerator.js`
- `index.html`
- `README.md`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`

## Melhorias em estradas

- Adicionado material de asfalto com textura procedural via `CanvasTexture`.
- Adicionada base escura sob o asfalto para remover aparência de fita chapada.
- Adicionadas bordas laterais/ombros visuais.
- Calçadas agora são renderizadas com camada própria e guia/meio-fio quando a via é térrea e zoneável.
- Marcação de pista foi reorganizada:
  - mão dupla usa dupla faixa amarela central;
  - mão única remove centro amarelo e usa tracejado branco entre faixas;
  - vias com múltiplas faixas ganham divisões brancas mais limpas.
- Nós debug amarelos não são mais renderizados permanentemente; apenas o nó ativo da ferramenta aparece como guia.
- Interseções passaram a ter base e asfalto em camadas.

## Melhorias em trilhos

- Adicionado material de lastro de brita procedural.
- Trilhos ganharam base visual mais larga.
- Trilho duplo agora é renderizado como duas vias ferroviárias visuais com quatro barras metálicas.
- Dormentes ganharam material próprio.
- Nós debug de trilho não aparecem mais permanentemente.

## Materiais novos

- `roadBase`
- `curb`
- `laneEdgeWhite`
- `railSleeper`
- texturas procedurais para asfalto, concreto e brita

## Compatibilidade mantida

- O gerador novo continua sendo o host principal.
- O jogo antigo continua apenas como legado/fonte de sistemas.
- RoadCore, zoneamento, veículos e save/load foram preservados.
- `.bat` e `.sh` foram atualizados para v1.5.
- Schema salvo atualizado para `newcore-save-v1.5`.

## Validação

Executado:

```bash
npm run check
```

Resultado: passou sem erro de sintaxe.

Servidor local testado via Python/urllib em porta temporária, com resposta HTTP 200 para:

- `/`
- `/src/main.js`
- `/src/systems/RoadSystem.js`
- `/src/systems/RailSystem.js`
- `/src/utils/Materials.js`

## Observação

Foi tentada validação visual em Chromium headless, mas o ambiente não finalizou a renderização WebGL dentro do tempo limite. A validação visual real ainda deve ser feita no Chrome desktop.

## Próxima etapa

Etapa 7/10 — `v1.6-transit-alpha`:

- paradas de ônibus;
- linhas editáveis;
- capacidade e lotação;
- receita por linha;
- painel de transporte;
- maior integração com passageiros/hora.
