# Relatório técnico — TerraNova NewCore v1.6 Transit Alpha

## Etapa

7/10 — Transporte público alpha.

## Objetivo

Adicionar uma primeira camada funcional de transporte público sem fugir da nova arquitetura: o gerador de mapas permanece como host, e os sistemas antigos seguem apenas como referência/adaptação.

## Implementado

- Novo `TransitSystem.js`.
- Grupo visual `newcore-transit`.
- Paradas de ônibus posicionadas com snap em vias térreas compatíveis com ônibus.
- Bloqueio básico para parada em água, via elevada/túnel e segmentos sem permissão de ônibus.
- Criação manual de linha por cliques em paradas.
- Conclusão de linha por botão ou tecla Enter.
- Criação automática de paradas e linha inicial usando construções/trechos viários como âncoras.
- Renderização de paradas com placa, poste, abrigo, banco e base.
- Renderização de cobertura de parada e traçado de linha de ônibus.
- Métricas por linha: comprimento, veículos, passageiros/hora, lotação, receita/h e custo/h.
- Métricas globais: paradas, linhas de ônibus, cobertura, lotação, receita e custo.
- `VehicleSystem` passou a usar os planos de rota do `TransitSystem` para gerar ônibus.
- `SimulationSystem` passou a considerar receita tarifária e custo operacional do transporte.
- UI atualizada com botões `Parada bus`, `Linha bus`, `Auto linha ônibus`, `Concluir linha`, `Limpar rascunho`.
- Inicializadores `.bat` e `.sh` atualizados para v1.6.

## Validação

- `npm run check` deve verificar todos os módulos JS com `node --check`.
- Servidor local esperado em `http://127.0.0.1:8123/`.

## Limitações conhecidas

- Paradas ainda são simplificadas, sem escolha manual de lado.
- Linhas ainda não têm painel completo por linha.
- A lotação é estimada por cobertura/demanda, não por passageiro individual.
- Ônibus seguem rota por grafo, mas ainda não param fisicamente em ponto com tempo de embarque.

## Próxima etapa

8/10 — Rail/Metro Alpha: estações, linhas ferroviárias mais reais, trem/metrô/VLT e integração com demanda.
