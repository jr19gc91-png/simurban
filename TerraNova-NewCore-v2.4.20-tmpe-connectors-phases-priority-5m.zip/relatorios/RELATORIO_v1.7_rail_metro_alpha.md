# Relatório técnico — TerraNova NewCore v1.7 Rail/Metro Alpha

## Etapa

8/10 — `v1.7-rail-metro-alpha`.

## Objetivo

Adicionar uma camada ferroviária/metrô alpha em cima do NewCore, mantendo o novo gerador de mapas como host principal e preservando o código antigo apenas como referência/legado.

## Implementado

### Ferramentas novas

- `Estação`: cria estação com snap em segmento de trilho.
- `Linha trilho`: monta linha ferroviária clicando em estações.
- `Auto linha trilho`: cria estações/linha automaticamente quando há trilhos suficientes.
- `Concluir trilho`: finaliza rascunho manual.
- `Limpar rascunho trilho`: limpa a seleção da linha ferroviária.

### RailSystem

- Adicionadas `railStations` e `railDraft` no estado.
- Renderização de estação com plataforma dupla, cobertura, passarela, pilares e placa.
- Cobertura visual de estação.
- Rota ferroviária por grafo de trilhos usando Dijkstra.
- Linha ferroviária baseada em sequência de estações.
- Render de linha ferroviária em faixa amarela.
- Remoção de estação via ferramenta Demolir.
- Auto criação de estações em trilhos longos.
- Métricas ferroviárias:
  - estações;
  - linhas;
  - demanda;
  - lotação;
  - receita;
  - custo operacional.

### VehicleSystem

- Trens agora usam planos de linha ferroviária reais quando disponíveis.
- Fallback de trem livre continua existindo para trilhos sem linha.
- Trem visual trocado para composição curta de 3 carros.

### Simulação

- Métricas ferroviárias integradas à simulação.
- Receita/custo ferroviário somado ao transporte público sem sobrescrever ônibus.
- Passageiros/hora consideram ônibus + ferrovia.

### UI/HUD

- Botões novos na bottombar:
  - Estação;
  - Linha trilho.
- Ações novas no painel lateral:
  - Auto linha trilho;
  - Concluir trilho;
  - Limpar rascunho trilho.
- Stats novas:
  - Estações;
  - Linhas trilho;
  - Lotação rail.

### Save/load

- Schema atualizado para `newcore-save-v1.7`.
- Save/load preserva:
  - `railStations`;
  - `railDraft`;
  - linhas ferroviárias em `transitLines` com `mode: 'rail'`.

## Validação

Executado:

```bash
npm run check
```

Resultado: sem erro de sintaxe nos módulos JS.

Também validado via servidor local HTTP nos arquivos principais:

- `/`
- `/src/main.js`
- `/src/systems/RailSystem.js`
- `/src/systems/VehicleSystem.js`
- `/src/ui/UISystem.js`

## Limitações conhecidas

- Ainda não há editor avançado de estações/tipos: trem, metrô, VLT.
- Trilhos elevados/túneis ferroviários ainda estão no alpha visual.
- As linhas ferroviárias usam o grafo atual de trilhos; cruzamentos/sinalização ferroviária avançada ficam para depois.
- Sem timetable real ou headway configurável por linha ainda.

## Próxima etapa sugerida

9/10 — `v1.8-economy-rci-alpha`:

- demanda RCI mais coerente;
- impostos;
- custo de manutenção por infraestrutura;
- crescimento urbano mais controlado;
- ligação entre transporte, acesso e valorização/crescimento;
- painel econômico/RCI mínimo.
