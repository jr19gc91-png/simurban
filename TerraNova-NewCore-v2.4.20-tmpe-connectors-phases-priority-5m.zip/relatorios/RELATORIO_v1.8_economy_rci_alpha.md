# Relatório técnico — TerraNova NewCore v1.8 Economy/RCI Alpha

## Etapa

9/10 — `v1.8-economy-rci-alpha`.

## Objetivo

Adicionar uma camada econômica e RCI mais coerente sem voltar para a arquitetura antiga. O gerador segue como host principal e o código antigo permanece apenas como referência.

## Implementado

### RCI

- Demanda residencial/comercial/industrial em `simulation.demand`.
- Cálculo de RCI baseado em:
  - acesso viário;
  - empregos disponíveis;
  - população;
  - ocupação de moradia/empregos;
  - lotes vazios por zona;
  - cobertura de ônibus/ferrovia;
  - congestionamento.

### Ocupação e satisfação

- Edifícios agora possuem capacidade potencial (`residentCapacity`/`jobCapacity`).
- Ocupação passa a variar conforme demanda, acesso, transporte, satisfação e congestionamento.
- Cada edifício recebe `satisfaction` e `landValue`.
- A cidade calcula satisfação média e valor médio do solo.

### Economia

- Impostos/hora calculados por população, empregos e valor do solo.
- Custos/hora separados em:
  - infraestrutura viária/ferroviária;
  - serviços urbanos;
  - custo de congestionamento;
  - transporte público.
- Saldo/hora aplicado ao dinheiro no tick horário.

### Crescimento

- Edifícios podem subir ou cair de nível conforme demanda, satisfação, acesso, valor do solo e congestionamento.
- Evolução altera altura e capacidade.
- Crescimento de novos edifícios usa RCI e acesso do lote.

### UI

- Painel mostra:
  - RCI R/C/I;
  - satisfação;
  - valor do solo;
  - impostos/h;
  - saldo/h.
- Inspetor de lote ocupado mostra nível, satisfação, valor, população e empregos.

## Correções/otimizações

- Removida duplicação de props de cobertura em edifícios comerciais (`addRooftopProps` era chamado duas vezes).
- `clearCity()` agora reseta a simulação usando o estado inicial completo, evitando sobras de métricas econômicas antigas.

## Save/load

- Schema atualizado para `newcore-save-v1.8`.
- Campos novos são preenchidos por default no `SimulationSystem`, mantendo compatibilidade parcial com saves anteriores.

## Validação

- `npm run check` passou sem erro.
- Servidor local testado com HTTP 200 para `index.html`, `src/main.js`, `src/systems/SimulationSystem.js`, `src/systems/BuildingSystem.js` e `src/ui/UISystem.js`.

## Próxima etapa

10/10 — Polish/QA/Performance:

- revisar bugs visuais e de fluxo;
- melhorar save/load;
- reduzir custo de render quando houver muitos objetos;
- ajustar HUD/interface para 1366×768 e 1920×1080;
- consolidar primeira Alpha testável.
