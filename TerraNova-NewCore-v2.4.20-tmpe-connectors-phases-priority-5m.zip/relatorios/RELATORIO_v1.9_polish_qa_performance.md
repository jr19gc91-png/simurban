# Relatório técnico — v1.9 Polish/QA Performance

## Objetivo

Fechar a etapa 10/10 como base Alpha inicial, sem fugir do `.md` raiz na parte de simulação/economia e mantendo o NewCore modular.

## Alterações principais

- Criado `src/utils/GameBalance.js` com constantes oficiais do escopo:
  - níveis -5 a +5;
  - 1 dia = 30 min reais;
  - velocidades 1x a 5x;
  - 2,5 viagens/cidadão/dia;
  - viés do carro 1.5;
  - desemprego 15%;
  - superlotação 120% da capacidade em pé;
  - capacidades de ônibus, VLT e trem/metrô.
- `SimulationSystem.js` virou orquestrador.
- Criados módulos:
  - `SimulationAccess.js`;
  - `RCIModel.js`;
  - `EconomyModel.js`;
  - `MobilityModel.js`;
  - `ComplianceAudit.js`.
- Transporte público passou a calcular:
  - capacidade sentada/em pé;
  - capacidade normal/h;
  - capacidade máxima com superlotação/h;
  - passageiros deixados para trás;
  - penalidade de conforto;
  - qualidade da linha;
  - receita por tarifa;
  - custo operacional baseado em frota, manutenção, combustível/energia e estações/paradas.
- Simulação agora calcula:
  - participação modal agregada carro/TP/bike;
  - desemprego;
  - pressão de favela;
  - penalidade média de conforto;
  - snapshot de compliance com o escopo.
- UI recebeu indicadores de modal share, desemprego e conforto TP.
- Seletor de nível ajustado para -5 a +5.
- Criado `tools/audit-modules.mjs` e `npm run audit` para evitar regressão para monólito.

## Modularização

Não existe `game.js` monolítico na raiz. O runtime está separado por responsabilidades em `src/map`, `src/game`, `src/systems`, `src/systems/simulation`, `src/ui`, `src/utils` e `src/assets`.

Módulos grandes ainda candidatos a fatiamento posterior:

- `RoadSystem.js` — próximo alvo natural: `RoadRenderer`, `RoadGraph`, `RoadBuilder`.
- `MapGenerator.js` — próximo alvo natural: `Terrain`, `Hydrology`, `Vegetation`, `Materials`.
- `RailSystem.js` — próximo alvo natural: `RailRenderer`, `RailLines`, `RailStations`.

## Pendências importantes

- Teste visual real em Chrome desktop.
- Favelas procedurais renderizadas e removíveis.
- Eventos dinâmicos: acidente, pane, enchente, protesto, obra.
- Semáforos funcionais com ciclos.
- Rampas reais com inclinação máxima.
- IA por faixa individual e não só por segmento.
- Save automático IndexedDB.

## Validação realizada

- `npm run check`
- `npm run audit`
- servidor local com HTTP 200 para arquivos principais.
