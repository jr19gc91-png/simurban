# Relatório Técnico — Terra Nova NewCore v2.0 Infra Renderer Transplant

## Etapa

**11/22 — Infra Renderer Transplant**

## Objetivo

Melhorar a renderização de estradas e trilhos do NewCore sem trocar o gerador de mapas, sem puxar o visual do jogo antigo como bloco fechado e sem usar o novo ZIP de construções/zoneamentos como base visual.

## Decisões respeitadas

- O gerador procedural novo continua sendo o host do jogo.
- O jogo antigo serve como fonte adaptável de sistemas/lógica, não como base principal.
- O ZIP de construções/zoneamentos aprovado não foi implantado e não foi usado como referência visual.
- O visual de construções será criado do zero em fase própria, adaptado ao mapa novo.
- O projeto continua modularizado, sem `game.js` gigante.

## Alterações principais

### Estradas

- Refeito o cálculo visual de largura de via com base em quantidade de faixas e direção.
- Adicionado helper `getConfiguredRoadWidth()`.
- Adicionado helper `getSegmentWidth()`.
- Adicionado helper `getLaneLayout()`.
- Asfalto agora recebe desgaste por faixa com `renderAsphaltWear()`.
- Marcação de pista recalculada:
  - mão dupla: dupla faixa amarela contínua no centro;
  - múltiplas faixas: brancas tracejadas por sentido;
  - mão única: brancas tracejadas entre faixas, sem amarela central.
- Setas agora são geradas por faixa visual.
- Overlays de classe de faixa agora são aplicados em faixas externas coerentes.
- Interseções receberam flares alinhados aos segmentos conectados.
- Sistema de tracejado refeito por distância real, evitando dashes quebrados em curvas.

### Trilhos

- Segmentos ferroviários novos agora usam `geometry: 'smooth'`.
- `getSegmentSamples()` do trilho passou a usar Hermite quando há continuidade de nós.
- Adicionados helpers ferroviários:
  - `hermite2D()`;
  - `normalize2D()`;
  - `getEndpointTangent()`.
- Dormentes corrigidos para ficar perpendiculares ao sentido do trilho.
- Trilhos receberam base de ferrugem com barra metálica superior.
- `buildOffsetRibbon()` dos trilhos preserva delta de altura do sample original.
- Preview ferroviário agora usa curva suave quando possível.

### Materiais

- `asphaltTexture()` refeito com granulação, remendos e manchas discretas.
- `ballastTexture()` refeito com leitura mais forte de brita.
- Adicionados materiais:
  - `roadWear`;
  - `roadPatch`;
  - `railRust`.
- Opacidade de faixas, zebras, setas e linhas de retenção ajustada para leitura melhor.

## Arquivos alterados

- `src/systems/RoadSystem.js`
- `src/systems/RailSystem.js`
- `src/utils/Materials.js`
- `README.md`
- `index.html`
- `package.json`
- `src/game/GameState.js`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`

## Validação executada

```bash
npm run check
npm run audit
```

Resultado da auditoria:

```text
modules=24
totalLines=6173
maxModuleLines=1164
```

Maior módulo ainda é `src/systems/RoadSystem.js`. Próximo fatiamento recomendado: `RoadRenderer`, `RoadMarkings`, `RoadIntersections` e `RoadGraph`.

## Validação HTTP

Servidor local respondeu HTTP 200 para:

- `/`
- `/src/main.js`
- `/src/systems/RoadSystem.js`
- `/src/systems/RailSystem.js`
- `/src/utils/Materials.js`

## Limitações conhecidas

- Não houve validação visual completa em Chrome/WebGL dentro deste ambiente.
- Interseções ainda não são geometria booleana real; receberam preenchimento visual melhorado, mas ainda precisam de renderização específica por tipo T/+.
- Trilho curvo visual foi melhorado, mas ainda não há regra ferroviária real de raio mínimo.
- Avenida com canteiro central ainda não está separada como tipo próprio.
- Calçadas/zoneamento ainda precisam da fase 15/22 para grade Cities-like correta.

## Próxima etapa

**12/22 — UI Shell Transplant**

Foco: reorganizar UI com topbar, bottombar, lateral de dados, minimapa e tool panels, reaproveitando conceito/estrutura do jogo antigo sem copiar DOM/CSS bruto.
