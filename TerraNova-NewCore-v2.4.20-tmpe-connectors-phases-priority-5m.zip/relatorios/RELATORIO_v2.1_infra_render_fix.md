# Relatorio v2.1 - Infra Render Fix

Versao: `TerraNova-NewCore-v2.1-infra-render-fix`

Base principal: `TerraNova-NewCore-v2.0-infra-render-transplant.zip`

Fonte legada consultada: `TerraNova-v3.36.85-html-lighting-texture-lotlevel.zip`

## Arquivos alterados

- `index.html`
- `README.md`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `src/utils/Materials.js`
- `src/systems/RoadSystem.js`
- `src/systems/RailSystem.js`

## Arquivos criados

- `src/roads/RoadRenderer.js`
- `src/roads/RoadMarkings.js`
- `src/roads/RoadIntersections.js`
- `src/roads/RoadMaterials.js`
- `src/rail/RailRenderer.js`
- `src/rail/RailGeometry.js`
- `tools/check-js.mjs`
- `relatorios/RELATORIO_v2.1_infra_render_fix.md`

## O que foi extraido/adaptado do legado

- Auditoria do legado localizou as referencias principais em `game.js`:
  - `pathCurveForRoad`
  - `makeRibbon`
  - `makeRoadOverlayFromCurve`
  - `roadLaneMetrics`
  - `renderRoad`
  - `addRoadSidewalks`
  - `addRoadMarkings`
  - `addDashedRoadLine`
  - `addRoadDirectionArrows`
  - `renderRoadJunctions`
  - `junctionHullWorld`
  - `renderRail`
  - `pathCurveForRail`
- Ideias adaptadas:
  - corpo de via como ribbon continua, com largura derivada de faixas;
  - sobreposicoes de pintura como ribbons/decal acima do asfalto;
  - cruzamento por hull/poligono dos bracos, evitando disco preto;
  - setas por faixa com geometria triangulada;
  - lastro e barras metalicas seguindo amostragem curva;
  - dormentes orientados pela tangente local do trilho.

## O que foi evitado

- Nao foi copiado o `game.js` legado.
- Nao houve substituicao do gerador de mapas.
- Nao houve alteracao de economia, RCI, transporte publico, edificios, zoneamento ou ciclo dia/noite.
- Nao foi importado visual antigo de ceu, sol, sombra, fog, tone mapping, luz ambiente ou modo noite.
- O ZIP de assets/zoneamentos nao foi usado como referencia visual.

## Correcoes implementadas

- `RoadRenderer` passou a gerar `road-base-*` e `road-asphalt-*` como malhas continuas visiveis.
- Hotfix visual: a ordem dos indices das ribbons foi invertida para normals voltadas para cima; isso corrige o caso em que so marcacoes apareciam porque o corpo opaco da via era culled.
- Hotfix visual: `road` agora usa textura de asfalto com multiplicador claro e `DoubleSide`, evitando corpo preto/invisivel.
- Hotfix visual: as setas bidirecionais foram invertidas para a convencao de trafego pelo lado direito usada pelo jogo.
- A ribbon de asfalto recalcula altura nas bordas esquerda/direita, reduzindo clipping em terreno inclinado.
- Marcações, setas, corredor de onibus, ciclovia e estacionamento foram baixados para ficar colados sobre a via.
- Intersecoes agora usam preenchimento de asfalto por hull integrado aos bracos conectados.
- Materiais foram ajustados para remover pads pretos fortes e brancos com aparencia de papel.
- `RailRenderer` gera base, lastro, dormentes e barras metalicas em curvas.

## Testes feitos

- Checagem sintatica por kernel Node interno em 30 modulos de `src`, sem falhas.
- Auditoria modular equivalente a `npm run audit`:
  - `modules=30`
  - maior modulo: `src/systems/RoadSystem.js`, 1158 linhas
  - nenhum modulo acima de 1200 linhas
  - sem `game.js` monolitico na raiz
- Servidor local iniciado por Python em `http://127.0.0.1:8123/`.
- HTTP 200 validado para:
  - `/`
  - `/src/roads/RoadRenderer.js`
  - `/src/rail/RailRenderer.js`
- Tentativa de abertura no navegador integrado: canvas e UI carregaram uma vez, mas a conexao do navegador integrado ficou instavel durante reloads posteriores.

## Pendencias

- Rodar `npm run check` e `npm run audit` em ambiente com Node/npm no PATH.
- Fazer QA visual manual no navegador com criacao de vias curvas, T/+, corredor de onibus, ciclovia, estacionamento e trilhos simples/duplos.
- Em etapa futura, refatorar/remover os metodos antigos de render ainda mantidos como compatibilidade interna em `RoadSystem.js` e `RailSystem.js`.
