# RELATÓRIO v2.2.1 — Road Signage Fix

## Objetivo
Corrigir a leitura visual das estradas que estavam com asfalto melhorado, mas sinalização horizontal fraca/quase invisível em câmera alta e baixa.

## Arquivos alterados
- `src/roads/RoadMaterials.js`
- `src/roads/RoadMarkings.js`
- `src/roads/RoadIntersections.js`
- `src/roads/RoadRenderer.js`
- `src/utils/Materials.js`
- `package.json`

## Ajustes feitos
1. Aumentado o contraste e opacidade da sinalização horizontal:
   - faixas brancas;
   - dupla faixa amarela;
   - faixas de borda;
   - setas;
   - faixas de pedestre;
   - linhas de retenção.

2. Corrigida prioridade de renderização das marcações:
   - marcações agora recebem `renderOrder` alto;
   - `frustumCulled = false` para evitar sumiço indevido;
   - materiais de sinalização receberam `polygonOffset` para reduzir z-fighting contra o asfalto e os pads de cruzamento.

3. Melhorada a leitura das vias em todos os segmentos:
   - bordas brancas contínuas nas pistas;
   - dupla faixa amarela mais larga e mais alta;
   - tracejado branco mais visível;
   - setas aparecem também em segmentos menores, não só em vias longas.

4. Melhorada a sinalização em cruzamentos:
   - guias de faixa entram nos braços dos cruzamentos;
   - pads de interseção deixam de parecer grandes manchas cinzas sem leitura;
   - faixas de pedestre e linhas de parada ficam acima do asfalto com maior contraste.

5. `buildFlatRect` agora recebe UVs, preparando o renderer para futuras pinturas/textos no asfalto sem mexer de novo na geometria base.

## Validação
Executado:

```bash
node tools/check-js.mjs
node tools/audit-modules.mjs
```

Resultado:

```txt
checked=34
modules=34 totalLines=8389 maxModuleLines=1158
```

Sem erro de sintaxe e sem módulo acima do limite de 1200 linhas.

## Observação
Correção focada em sinalização horizontal/renderização. Não transforma o sistema em TMPE faixa-a-faixa real; isso continua sendo escopo separado.
