# RELATÓRIO v2.2.2 — Bazzite SH Fix

## Objetivo
Corrigir e atualizar o inicializador `iniciar-terra-nova-bazzite.sh` da versão v2.2.1 Road Signage Fix.

## Alterações

- `iniciar-terra-nova-bazzite.sh`
  - Atualizado para v2.2.2.
  - Adicionado `set -Eeuo pipefail`.
  - Verifica se `index.html` existe antes de subir servidor.
  - Detecta `python3` ou `python` automaticamente.
  - Permite sobrescrever com `PYTHON_BIN=/caminho/python3`.
  - Detecta porta ocupada e tenta portas seguintes automaticamente.
  - Permite sobrescrever porta com `PORT=8124`.
  - Abre navegador por `xdg-open`, `gio`, Chrome/Chromium ou Firefox.
  - Mantém o servidor vivo até CTRL+C.
  - Mostra log claro caso o servidor não suba.

- Versões atualizadas:
  - `package.json`: 2.2.2.
  - `src/map/MapGenerator.js`: `TerraNova-NewCore-v2.2.2-bazzite-sh-fix`.
  - `src/game/GameState.js`: `newcore-save-v2.2.2`.
  - `index.html` e `README.md`: textos de versão atualizados.

- `tools/smoke-newcore.mjs`
  - Removido caminho hardcoded `/home/claude`.
  - Busca Playwright no projeto primeiro.
  - Se Playwright não existir, sai com código 2 em vez de fingir sucesso.

## Validação

- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
- `node -e "JSON.parse(require('fs').readFileSync('package.json','utf8')); console.log('package ok')"`

## Observação
O smoke test depende de Playwright instalado no ambiente. Agora, se ele não estiver instalado, o script informa claramente e não marca o teste como aprovado.
