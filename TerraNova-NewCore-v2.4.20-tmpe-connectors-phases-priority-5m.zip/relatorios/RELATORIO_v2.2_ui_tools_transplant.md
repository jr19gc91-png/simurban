# Relatorio v2.2 - UI & Tools Transplant

Versao: `TerraNova-NewCore-v2.2-ui-tools-transplant`

Etapa **12/22** da trilha NewCore (UI Shell Transplant).

Base principal: `TerraNova-NewCore-v2.1-infra-render-fix`.

Fonte de referencia: jogo antigo (`game.original.js`, 18025 linhas) usado **somente** como referencia de interface e regras. Nenhum gráfico do mundo antigo foi importado.

## Objetivo da tarefa

Transplantar mecanicas, regras, interface e ferramentas do jogo antigo para o NewCore, com tres restricoes do Jonathan:
1. Adaptavel ao gerador de mapas novo.
2. Trazer principalmente a **interface** (painéis, minimapa, ferramentas).
3. **Nada** de gráfico do jogo antigo (céu, sol, sombra, fog, luz, mapa, terreno, assets).

## Auditoria (antes de codificar)

- O NewCore ja estava muito mais completo do que o enquadramento sugeria: os 8 sistemas (vias, trilhos, zoneamento, transporte, construções, veículos, simulacao, input) ja funcionavam ponta a ponta sobre o mapa novo (construir vias/zonas/construções/linhas, veículos circulando, simulacao avancando: populacao, empregos, caixa, congestionamento, modal, RCI, economia).
- O **gap real** era a camada de interface do jogo antigo (painéis de dados, minimapa, alternancia de camadas) e algumas ferramentas (mini-TMPE).
- O estado de simulacao do NewCore e mais enxuto que o do antigo: vários campos que os painéis antigos liam nao existem aqui. Por isso os painéis foram **adaptados** para ler o estado real do NewCore, nao copiados verbatim.

## Arquivos criados

- `src/ui/InfoPanels.js` — dock de 7 botões + painel dinamico (populacao/financas/transporte/linhas/veículos/tráfego/gráficos), no idioma visual do jogo antigo, lendo estado do NewCore. Inclui abas, barras, cartões de linha e mini-gráficos SVG de histórico.
- `src/ui/Minimap.js` — minimapa 2D top-down: fundo de terreno em cache (amostragem de altura/água), sobreposicao de vias/trilhos/zonas/construções/paradas/estações/linhas/veículos ao vivo, marcador da câmera, clique-para-reposicionar e 4 botões de camada. Throttle ~12fps.
- `src/systems/TrafficControlSystem.js` — mini-TMPE: controle por nó (semáforo/pare/preferencial) e permissoes de faixa por segmento (reaproveitando `laneClass`). Marcadores procedurais low-poly. Logica de fase (`greenAxisAt`, `redForHeading`) lida pelos veículos.
- `src/ui/Shortcuts.js` — botão `?` + modal de atalhos de teclado, autocontido.
- `tools/smoke-newcore.mjs` — smoke test headless (Playwright) com regex de versao flexivel.
- `relatorios/RELATORIO_v2.2_ui_tools_transplant.md` — este relatorio.

## Arquivos alterados

- `src/main.js` — instancia InfoPanels, Minimap, Shortcuts; expõe em `window.TerraNovaNewCore`.
- `src/game/GameShell.js` — grupo `trafficControls`; instancia `systems.traffic`; avanco do tempo de semáforo no loop; render dos controles e `applyViewLayers` no rebuild; metodos `toggleViewLayer`/`applyViewLayers`/`applyGrid`/`handleTrafficControlClick`/`setTmpeMode`; reset de controles no `clearCity`.
- `src/game/GameState.js` — `simulation.history`, `viewLayers`, `trafficControls`, `tmpeMode`.
- `src/systems/SimulationSystem.js` — `historyLimit` + `pushHistory()` no tick horario (buffer circular de 48 pontos).
- `src/systems/VehicleSystem.js` — integracao com semáforos: `nearestApproachingControl()` e parada/reducao no nó controlado à frente (trens isentos).
- `src/systems/InputController.js` — ferramenta `tmpe` roteia o clique conforme o modo (cruzamentos/permissoes).
- `src/ui/UISystem.js` — painel TMPE (botões de modo, limpar, resumo) e seu render.
- `index.html` — botão "Tráfego", seccao `#tmpePanel`, strings de versao v2.2.
- `styles/newcore.css` — estilos do dock/painel de dados, minimapa, painel TMPE e atalhos, no idioma visual existente, com responsivo.
- `package.json` — nome/versao 2.2.0.
- `README.md` — etapa 12/22 e descricao das entregas.

## Decisao tecnica relevante (cleanup de rede x lotes)

Durante o smoke test apareceu um caso de borda: ao reconstruir a cidade passando `roads:true` **logo apos** zonear, `cleanupNetwork` mescla nós duplicados (ex.: o nó de fechamento de um loop) e os lotes recem-criados perdem o `roadId`, levando `cleanupInvalidLots` a remover lotes e suas construções.

- No **fluxo real** isso nao ocorre: `InputController.paintZone` reconstroi com `{ zoning, buildings, vehicles }` (sem `roads`), entao os lotes sobrevivem.
- No **save/load** (que passa `roads:true` via `importSaveObject`) verificou-se que `cleanupNetwork` preserva o `id` do segmento (`{ ...raw, a, b }`); para uma cidade salva limpa nada e mesclado/removido, e os lotes/construções permanecem validos. O round-trip do smoke test confirma: vias, lotes, construções e controles de tráfego preservados.
- O smoke test foi ajustado para espelhar o fluxo real (vias longas retas, rebuild sem `roads` apos zonear), refletindo o comportamento de jogo e nao um artefato de teste.

## Validação (numerica e headless)

- `node tools/check-js.mjs` -> **34 módulos** sem erro de sintaxe.
- `node tools/audit-modules.mjs` -> maior módulo **1158 linhas** (RoadSystem), abaixo do limite de 1200.
- `node tools/smoke-newcore.mjs` -> **todos os testes passam**: versao, 8 sistemas, malhas de via (289) e construcao (176), semáforo + 5 malhas de marcador, alternancia de camada, dock de 7 botões, minimapa, atalhos, conteudo dos 7 painéis e round-trip salvar/carregar.
- Histórico validado em runtime: 6 pontos acumulados em ~6 horas de jogo, 6 mini-gráficos desenhados.
- Capturas headless conferem visualmente o minimapa (terreno/vias/câmera), o painel Gráficos (resumo e séries) e o painel do gestor de tráfego.

## Estimativa honesta de conclusao

**Concluido nesta etapa:** painéis de dados (7), minimapa interativo, mini-TMPE (semáforo/pare/preferencial + permissoes de faixa) com veículos respeitando semáforos, alternancia de camadas, atalhos, gráficos de histórico e campos novos no salvar/carregar.

**Adiado / nao incluido:** edicao de terreno em jogo (risco vs gerador novo), incidentes/eventos, visao subterranea, TMPE avancado (conectores faixa-a-faixa), e ajustes de qualidade gráfica (excluidos por serem gráfico do mundo).

## Como rodar

```bash
./iniciar-terra-nova-bazzite.sh     # ou iniciar-terra-nova-windows.bat
# servidor manual:
python -m http.server 8123 --bind 127.0.0.1
```
