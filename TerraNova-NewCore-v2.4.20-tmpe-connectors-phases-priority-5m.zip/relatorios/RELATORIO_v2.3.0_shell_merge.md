# RELATÓRIO v2.3.0 — Shell Merge

## Base usada

- Base oficial preservada: `TerraNova-NewCore-v2.2.2-bazzite-sh-fix.zip`.
- Referência visual mesclada: `03_TerraNova-NewCore-v3.3-game-ui-shell.zip`.

## Objetivo

Mesclar o melhor dos dois pacotes sem trocar o renderer real, sem remover sistemas funcionais e sem importar o canvas debug do shell v3.3.

## O que foi mantido da v2.2.2

- Gerador procedural real em Three.js.
- RoadCore, trilhos, zoneamento, construções, veículos, economia/RCI, transporte e save/load.
- Correção de sinalização viária da v2.2.1.
- Inicializador Bazzite/Linux robusto.
- Inicializador Windows.
- Painéis de dados, minimapa real e atalhos já conectados ao estado do jogo.

## O que foi aproveitado do v3.3 game-ui-shell

- Direção de layout mais limpa para HUD/topbar.
- Barra inferior mais legível, com ferramentas em formato de ícone + texto.
- Organização visual mais próxima de shell de jogo, sem substituir a renderização real.
- Melhor responsividade visual em telas menores.

## Alterações feitas

### Interface

- Atualizado `index.html` para v2.3.0.
- Barra inferior agora usa ícones e labels compactos.
- Topbar recebeu ajuste de largura, altura, espaçamento e truncamento de versão.
- Painéis de informação foram reposicionados para o lado esquerdo, reduzindo conflito com o painel de construção.
- Gerador lateral fica recolhido/semipresente no modo cidade e expande no hover.
- Minimapa foi movido para o lado direito com offset para não cobrir o painel de construção.
- `pill` inferior é ocultado no modo cidade para reduzir poluição visual.
- Responsividade refinada para 1320px, 1180px e 920px.

### Mini-TMPE / tráfego

- Texto ajustado para não fingir edição faixa-a-faixa: agora aparece como **classe do segmento**.
- `clearAll()` agora limpa:
  - controles de nós;
  - controles de segmentos;
  - todas as classes de segmento voltam para `general`;
  - vias, veículos e marcadores são reconstruídos.
- Marcadores de semáforo/pare/preferencial agora respeitam o nível da via (`elevation`).
- Veículos ignoram controles de tráfego em outro nível vertical, evitando semáforo de superfície afetar elevado/túnel sobreposto.
- Placa de `Pare` agora gera parada curta real antes de liberar o veículo, em vez de só reduzir velocidade.

### Versionamento

- `package.json`: `2.3.0`.
- `src/map/MapGenerator.js`: `TerraNova-NewCore-v2.3.0-shell-merge`.
- `src/game/GameState.js`: `newcore-save-v2.3.0`.
- `index.html`, `README.md`, `.sh` e `.bat` atualizados para v2.3.0.

## Validação executada

```bash
bash -n iniciar-terra-nova-bazzite.sh
node tools/check-js.mjs
node tools/audit-modules.mjs
node tools/smoke-newcore.mjs
```

Resultado:

```txt
checked=34
modules=34
totalLines=8416
maxModuleLines=1158
maior módulo: src/systems/RoadSystem.js
```

Smoke test:

```txt
Playwright não encontrado. Smoke test NÃO executado.
exit=2
```

O smoke está correto em não fingir sucesso quando Playwright não existe.

## Observação honesta

Esta versão não transforma o mini-TMPE em TMPE completo. A classe ainda é aplicada ao segmento inteiro. Edição faixa-a-faixa, conectores e fases manuais de semáforo devem ficar para uma rodada própria.
