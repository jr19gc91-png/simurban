# RELATÓRIO v2.3.10 - Classic Tools / Lane Hotfix

## Objetivo
Continuar a aproximação do NewCore ao modo clássico, corrigindo pontos funcionais que afetavam estrada/trilho e tráfego por faixa.

## Alterações principais
- Ferramenta de estrada ganhou botões rápidos de faixas 1–5 e níveis Subterrâneo/Superfície/Elevado.
- Estrada de terra ficou travada em 1 faixa, mão dupla, classe geral e sem zoneamento, como regra oficial.
- Corrigido `getLaneLayout` em RoadSystem: a variável `kind` agora é resolvida antes de ser usada.
- Segmentos de terra agora são criados normalizados, evitando avenida/ônibus/estacionamento por acidente.
- Ferramenta de trilhos ganhou modo Trem / VLT / Metrô e preset Subterrâneo -1.
- RailSystem passa a salvar `mode` no segmento ferroviário.
- RailRenderer usa escala/material diferente para VLT, preparando diferenciação visual.
- VehicleSystem recebeu `pickLaneIndexForVehicle`, que estava sendo chamado mas não existia; isso reduz erro runtime e melhora troca de faixa ao entrar em novo segmento.

## Validação
- bash -n iniciar-terra-nova-bazzite.sh
- node tools/check-js.mjs
- node tools/audit-modules.mjs
