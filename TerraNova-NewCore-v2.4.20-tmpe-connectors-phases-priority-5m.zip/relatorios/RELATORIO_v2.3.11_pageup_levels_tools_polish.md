# RELATÓRIO v2.3.11 - PageUp Levels / Tools Polish

## Objetivo
Atender a regra nova do usuário: níveis de estrada/trilho devem ser alterados por PageUp/PageDown, não pela interface das ferramentas.

## Alterações
- `index.html`
  - removidos botões de nível da ferramenta Estradas;
  - removido slider de nível da ferramenta Estradas;
  - removidos presets Superfície/Elevado/Subterrâneo da ferramenta Trilhos;
  - removido slider de nível da ferramenta Trilhos;
  - hints atualizados para orientar PageUp/PageDown.
- `src/ui/UISystem.js`
  - removidos binds e renderização de controles de nível inexistentes;
  - removidas ações de preset ferroviário que mudavam elevação pela UI.
- `src/systems/InputController.js`
  - PageUp/PageDown agora funciona para `road` e `rail`;
  - inspector mostra o nível atual após alteração.
- `src/ui/Shortcuts.js`
  - atalho documentado para via/trilho.
- Versionamento atualizado para v2.3.11.

## Validação
- bash -n iniciar-terra-nova-bazzite.sh
- node tools/check-js.mjs
- node tools/audit-modules.mjs
