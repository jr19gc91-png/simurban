# RELATÓRIO v2.3.12 - Classic UI Tools Preview

## Objetivo
Continuar a aproximação da interface e das ferramentas do modo antigo, mantendo o visual moderno de ambiente/terreno/iluminação do NewCore.

## Alterações
- `index.html`
  - painel de Estradas refeito em formato mais clássico e compacto;
  - painel de Trilhos refeito em formato mais clássico e compacto;
  - mantido nível apenas como leitura: PageUp/PageDown, sem botão de nível na UI.
- `src/ui/UISystem.js`
  - adicionados botões rápidos de velocidade para estrada/trilho;
  - adicionados indicadores passivos de nível atual para estrada/trilho;
  - mantido fluxo Novo Jogo -> Gerador -> Cidade.
- `src/systems/RoadSystem.js`
  - preview de estrada agora mostra largura real com marcações principais;
  - preview de avenida mostra canteiro central;
  - estrada de terra continua sem marcação viária.
- `src/systems/RailSystem.js`
  - preview de trilhos varia largura conforme simples/duplo e metrô.
- `styles/newcore.css`
  - adicionados estilos clássicos para ferramentas sem mexer no ambiente visual.

## Restrições mantidas
- Não foi alterado o visual de ambiente/terreno/luz do NewCore.
- Não foram reintroduzidos controles de nível na interface.
- PageUp/PageDown seguem como regra oficial de nível.
