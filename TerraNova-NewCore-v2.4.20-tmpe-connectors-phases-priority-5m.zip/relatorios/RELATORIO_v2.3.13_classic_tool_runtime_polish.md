# RELATÓRIO v2.3.13 - Classic Tool Runtime Polish

## Objetivo
Continuar a aproximação da interface e ferramentas ao modo antigo, mantendo o visual moderno do ambiente/mapa.

## Alterações principais
- Corrigido bug runtime em `RoadIntersections.js`: variável incorreta `roads` dentro de `buildIntersectionPad`.
- Implementado `renderIntersectionCoreGuide`, chamado desde versões anteriores mas inexistente; isso podia quebrar renderização de cruzamentos em runtime.
- Interseções receberam núcleo secundário e caps curtos para reduzir microfrestas em T/X/Y sem voltar com zebras brancas.
- Preview de estradas reforçado com discos de nó nas pontas para deixar o fluxo clássico de construção por nós mais claro.
- Preview de estradas usa deslocamento correto da faixa central conforme layout/canteiro.
- Preview de trilhos agora mostra lastro + linhas metálicas, diferenciando melhor simples/duplo/metrô/VLT antes do clique.
- Construção de estrada ficou mais limpa: classe de segmento saiu do painel principal e ficou indicada como recurso de Editar via/TMPE.
- Versionamento atualizado para `v2.3.13` e schema `newcore-save-v2.3.13`.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
