# RELATÓRIO v2.3.14 - Lane TMPE Classic Polish

## Objetivo
Continuar a aproximação das ferramentas/interface ao modo antigo, mantendo o ambiente moderno, e preparar a base real de edição por faixa para o TMPE.

## Alterações
- TMPE agora permite escolher alvo da classe: segmento inteiro ou faixa F1-F5.
- Segmentos de via passaram a aceitar `laneClasses[]` além de `laneClass` legado.
- Overlay visual das classes por faixa foi adicionado para ônibus/emergência/serviço/mista/bike/estacionamento.
- Veículos agora preferem faixas compatíveis quando `laneClasses[]` existe.
- `RoadSystem` ganhou helpers `getPrimaryLaneClass` e `getLaneClassForLane`.
- Save/schema atualizado para v2.3.14.

## Observações
- Ainda não é TMPE completo com conectores faixa-a-faixa.
- Esta versão cria a base para a próxima rodada de conectores e conversões por faixa.
