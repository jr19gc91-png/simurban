# RELATÓRIO v2.3.15 - TMPE Lane Explicit Tools

## Objetivo
Continuar a evolução da v2.3.14 mantendo o ambiente moderno e aproximando ferramentas/UI do comportamento clássico, com foco em TMPE por faixa mais direto.

## Alterações
- `GameState.js`: schema atualizado para `newcore-save-v2.3.15` e novo estado `tmpeLaneClass`.
- `GameShell.js`: adicionado `setTmpeLaneClass()` e o modo permissões agora aplica classe escolhida diretamente.
- `TrafficControlSystem.js`: novo método `setSegmentLaneClass(segment, laneIndex, laneClass)`.
- `UISystem.js`: botões de classe TMPE agora têm estado ativo e texto de dica dinâmico.
- `index.html`: painel TMPE ganhou seletor explícito de classe: Geral, Ônibus, Emergência, Serviço, Mista, Bike e Estacionamento.
- `styles/newcore.css`: pequenos ajustes para grade de classes TMPE.
- `MapGenerator.js`, `README.md`, `package.json`: versionamento atualizado para v2.3.15.

## Resultado
O TMPE deixou de depender só de ciclo ao clicar. Agora o usuário escolhe alvo (segmento/F1–F5) e classe, depois aplica diretamente na via.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
