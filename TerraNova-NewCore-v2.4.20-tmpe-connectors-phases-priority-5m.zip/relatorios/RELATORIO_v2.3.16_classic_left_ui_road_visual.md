# RELATÓRIO v2.3.16 - Classic Left UI / Road Visual Audit

## Objetivo
Corrigir a direção visual após feedback do usuário:
- manter o ambiente moderno do NewCore;
- trazer a interface para o modelo antigo: topbar + barra lateral esquerda + barra inferior;
- remover qualquer painel fixo do lado direito;
- registrar auditoria honesta do que já está igual ao modo antigo e o que ainda falta.

## Alterações aplicadas
- `styles/newcore.css`
  - painel de ferramentas movido do lado direito para a esquerda, ao lado da barra lateral clássica;
  - painéis/docks modernos do lado direito ocultados no modo cidade;
  - minimapa ocultado no modo cidade para cumprir a regra de não ter nada no lado direito;
  - atalhos movidos para o lado esquerdo;
  - ajustes de responsividade para não quebrar em telas menores.
- Versionamento atualizado para `v2.3.16`.

## Status: o que já está próximo do modo antigo
- Fluxo de telas separado: tela inicial, gerador e cidade.
- Topbar presente com menu hambúrguer.
- Barra inferior por categorias.
- Barra lateral esquerda com relatórios/linhas/economia/tráfego.
- Ferramentas de estrada/trilho usando submenus clássicos.
- Níveis por PageUp/PageDown, não pela interface.
- Estrada de terra com regra própria: 1 faixa, sem pintura e sem calçada.
- Rua, avenida e mão única presentes como presets.
- Trilho simples/duplo e modos Trem/VLT/Metrô presentes na UI.

## Status: o que ainda falta para ficar igual ao antigo
- Integrar 100% os submenus de ferramenta dentro da barra lateral esquerda, em vez de um segundo painel à esquerda.
- Recriar visual clássico exato das janelas, abas e botões do jogo antigo.
- Polir cruzamentos T/X/Y com geometria mais orgânica e menos sobreposição de peças.
- Criar rotatórias automáticas.
- Fazer continuidade visual perfeita das faixas de rolamento dentro dos cruzamentos.
- Reforçar preview de construção para se parecer mais com o antigo.
- Validar com o `.md` e o jogo antigo real quando o usuário reenviar os arquivos.

## Validação esperada
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
