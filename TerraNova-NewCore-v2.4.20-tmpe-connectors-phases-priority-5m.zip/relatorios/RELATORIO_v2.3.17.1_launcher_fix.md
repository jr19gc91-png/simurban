# RELATÓRIO v2.3.17.1 - Launcher Fix

## Objetivo
Corrigir os inicializadores Linux/Bazzite e Windows da base v2.3.17, que ainda estavam com metadados antigos e lógica frágil de abertura.

## Alterações
- `iniciar-terra-nova-bazzite.sh`
  - versão atualizada para v2.3.17.1;
  - valida `index.html`, `src/` e `vendor/`;
  - detecta `python3`, `python` ou `PYTHON_BIN`;
  - procura porta livre a partir de 8123;
  - abre navegador via `xdg-open`, `gio`, Chrome/Chromium ou Firefox;
  - grava log em `/tmp/terranova-newcore-server.log`;
  - mantém servidor vivo até `CTRL+C`;
  - permissão executável aplicada.
- `iniciar-terra-nova-windows.bat`
  - versão atualizada para v2.3.17.1;
  - valida pasta do jogo;
  - detecta `py -3`, `python` ou `python3`;
  - procura porta livre a partir de 8123;
  - abre navegador no endereço correto;
  - grava log em `%TEMP%\terranova-newcore-server.log`.
- `package.json` atualizado para `2.3.17.1`.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
