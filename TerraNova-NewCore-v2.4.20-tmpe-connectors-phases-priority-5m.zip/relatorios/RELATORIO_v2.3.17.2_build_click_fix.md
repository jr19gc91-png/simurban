# RELATÓRIO v2.3.17.2 - Build Click Fix

## Objetivo
Corrigir falha intermitente no segundo clique ao construir estradas/trilhos.

## Causa provável
O InputController usava evento `click` do browser e interseção com plano fixo `y=0`. Em terreno procedural com relevo, isso deslocava o ponto real clicado. Além disso, o evento `click` pode ser suprimido depois de pointer/preview/OrbitControls, causando sensação de clique travado.

## Alterações
- `src/systems/InputController.js`
  - construção agora confirma no `pointerup`, não no `click`;
  - canvas usa pointer capture durante o clique;
  - tolerância de microarrasto ajustada para 7 px;
  - `pickTerrainPoint` agora intersecta a superfície procedural por bisseção ao longo do raio da câmera;
  - árvores, rochas, estradas e previews são ignorados na seleção: o alvo é sempre o terreno procedural.
- Versionamento atualizado para `v2.3.17.2`.

## Validação
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
- `bash -n iniciar-terra-nova-bazzite.sh`
