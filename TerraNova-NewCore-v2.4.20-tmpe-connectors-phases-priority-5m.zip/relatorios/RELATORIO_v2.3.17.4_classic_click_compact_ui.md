# RELATÓRIO v2.3.17.4 - Classic Click / Compact UI

## Objetivo
Corrigir dois pontos reportados:
1. cliques de construção de estradas/trilhos ainda não pareciam o modo antigo;
2. submenus das ferramentas estavam grandes demais e ocupavam muito mapa.

## Alterações
- `src/systems/InputController.js`
  - estrada e trilho agora confirmam o ponto no `pointerdown`, como ferramenta clássica de construção por nós;
  - o segundo clique não depende mais de `click`/`pointerup`;
  - microarrasto, pointer capture e OrbitControls deixam de cancelar o segundo clique de via/trilho.
- `styles/newcore.css`
  - submenu acima da barra inferior ficou mais compacto;
  - largura/altura reduzidas;
  - textos explicativos e hints longos ocultos no modo cidade;
  - botões de ferramentas e submenus menores;
  - barra inferior mais baixa/compacta.
- Versionamento atualizado para `v2.3.17.4`.

## Mantido
- Topbar apenas status/dados.
- Lateral esquerda apenas dashboards.
- Ferramentas na barra inferior.
- Lado direito vazio no modo cidade.
- Ambiente moderno preservado.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
