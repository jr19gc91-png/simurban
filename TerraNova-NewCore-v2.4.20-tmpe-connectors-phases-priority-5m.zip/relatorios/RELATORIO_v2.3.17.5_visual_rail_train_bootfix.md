# RELATÓRIO v2.3.17.5 - Visual / Rail / Train / Boot Fix

## Objetivo
Corrigir três pontos reportados pelo usuário:
1. interface misturada por alguns segundos ao iniciar;
2. visual de estradas/trilhos ainda grosseiro;
3. trem virando como bloco único, sem articulação dos vagões nas curvas.

## Alterações
- `styles/newcore.css`
  - adicionada proteção `body:not(.app-ready)` para impedir flash de HUD/gerador/bottombar antes da UI definir o fluxo correto;
  - no modo cidade, `#ui` do gerador fica escondido.
- `src/ui/UISystem.js`
  - adiciona `body.app-ready` somente depois do primeiro render consistente.
- `src/roads/RoadMaterials.js`
  - reduzidos offsets verticais de interseções para elas não parecerem blocos elevados.
- `src/roads/RoadIntersections.js`
  - nós simples com 2 segmentos deixam de receber cruzamento circular gigante;
  - adicionada costura curta para curvas/continuações;
  - cruzamentos reais T/X/Y mantêm pad, mas com núcleo e flares menores.
- `src/rail/RailRenderer.js`
  - trilhos ficaram mais estreitos e proporcionais;
  - dormentes e metal dos trilhos foram refinados.
- `src/systems/VehicleSystem.js`
  - trem agora posiciona cada vagão separadamente ao longo da rota;
  - vagões passam a articular em curvas em vez de girar como conjunto rígido.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
