# RELATÓRIO v2.3.17 - Classic Bottom Tools UI

## Objetivo
Corrigir a arquitetura da interface para bater com o modo antigo descrito pelo usuário, mantendo o visual moderno do ambiente/mapa.

## Regra oficial aplicada
- Topbar: apenas dados/status do jogo.
- Lateral esquerda: apenas dashboards/relatórios.
- Barra inferior: ferramentas de construção.
- Submenus das ferramentas: acoplados acima da barra inferior.
- Lado direito: vazio no modo cidade.

## Alterações
- `styles/newcore.css`
  - painel de ferramenta reposicionado para o rodapé, acima da barra inferior;
  - painel de ferramenta oculto quando nenhuma ferramenta está ativa;
  - painel lateral esquerdo preservado apenas como dashboard;
  - minimapa, info dock, info panel, TMPE flutuante e pill ocultados no modo cidade para garantir lado direito vazio;
  - submenus de estrada/trilho/zoneamento/transporte/editar via/TMPE organizados em grid horizontal compacto.
- `src/map/MapGenerator.js`, `src/game/GameState.js`, `index.html`, `README.md`, `package.json`
  - versionamento atualizado para v2.3.17 / `newcore-save-v2.3.17`.

## Status comparativo com modo antigo
### Igual ou bem próximo
- Topbar como camada de status.
- Barra lateral esquerda como painel de dashboards.
- Barra inferior como entrada das ferramentas.
- Submenus de construção separados por ferramenta.
- Lado direito sem painel fixo.

### Ainda falta
- Recriar exatamente o desenho visual/medidas das janelas antigas.
- Polir cruzamentos para continuidade perfeita de faixas.
- Rotatórias automáticas.
- Comparar contra o `.md` e jogo antigo quando forem reenviados.
