# RELATÓRIO v2.3.18 - Classic UI / Road Rail / DayNight

## Objetivo
Consolidar a direção correta: interface/ferramentas no modelo antigo, ambiente moderno preservado, vias/trilhos visualmente menos quebrados, trem articulado e ciclo dia/noite ativo.

## Correções aplicadas
- UI clássica consolidada:
  - topbar em faixa superior fixa para status/dados;
  - lateral esquerda apenas para dashboards;
  - barra inferior apenas para ferramentas;
  - submenus compactos acima da barra inferior;
  - lado direito vazio no modo cidade.
- Ciclo dia/noite:
  - MapGenerator expõe `setTimeOfDay(hour, minute)`;
  - GameShell sincroniza luz, céu, fog e exposição com a hora da simulação.
- Estradas/cruzamentos:
  - removidos discos grandes em nós de continuidade;
  - reduzidos pads/caps de cruzamento;
  - continuidade visual menos “blocada” nas curvas.
- Trilhos:
  - lastro, dormentes e trilhos ficaram mais estreitos/proporcionais.
- Trem:
  - 4 carros menores;
  - cada carro calcula heading por frente/traseira no trecho;
  - couplers visuais entre vagões;
  - vagões devem articular melhor em curvas.

## Observação
As imagens enviadas mostram a aba rodando `v2.3.17.2 Build Click Fix`. Esta versão v2.3.18 consolida as correções posteriores e adiciona os ajustes desta rodada.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
