# RELATÓRIO v2.3.19.1 - Cache Proof Launchers

## Objetivo
Evitar que Chrome/servidor local mostrem uma versão antiga mesmo quando o usuário baixa o ZIP correto.

## Verificação
O ZIP v2.3.19 estava com os arquivos internos atualizados para v2.3.19, mas os launchers ainda mostravam texto antigo v2.3.17.1 e usavam `python -m http.server`, que pode permitir cache agressivo do navegador para módulos JS/CSS.

## Alterações
- Adicionado `tools/serve_no_cache.py`, servidor local com headers `Cache-Control: no-store`.
- Atualizado `iniciar-terra-nova-bazzite.sh` para usar servidor sem cache.
- Atualizado `iniciar-terra-nova-windows.bat` para usar servidor sem cache.
- Launchers agora abrem URL com parâmetro `?cache=...`.
- Launchers avisam quando a porta 8123 está ocupada, indicando possível servidor antigo rodando.
- `index.html` recebeu meta tags no-cache e cache-busting em CSS/JS.
- Versionamento atualizado para v2.3.19.1.

## Como testar corretamente
1. Extraia o ZIP em uma pasta nova.
2. Feche janelas antigas do servidor.
3. Execute `iniciar-terra-nova-windows.bat` ou `iniciar-terra-nova-bazzite.sh`.
4. Use a URL que o launcher abrir automaticamente.
5. Se aparecer v2.3.17.2, a aba ainda está apontando para servidor antigo.
