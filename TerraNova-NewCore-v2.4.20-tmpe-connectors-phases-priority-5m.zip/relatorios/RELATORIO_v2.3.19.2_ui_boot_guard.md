# RELATÓRIO v2.3.19.2 - UI Boot Guard

## Problema
Após o pacote anti-cache, o jogo podia abrir direto no mapa 3D/gerador sem HUD visível. Isso indicava que o fluxo visual ficou sem `start-mode`, `generator-mode` ou `city-mode`, ou que o CSS escondia todos os painéis quando o modo ainda não estava definido.

## Correções
- `index.html` agora inicia com `<body class="start-mode">`, garantindo tela inicial mesmo antes do JavaScript.
- `src/main.js` ganhou watchdog de boot: se nenhum modo visual existir após 350 ms, restaura `start-mode` e re-renderiza a UI.
- `styles/newcore.css` ganhou bloco final de guarda de UI:
  - `start-mode` mostra só a tela inicial;
  - `generator-mode` mostra o painel do gerador;
  - `city-mode` mostra topbar, lateral esquerda e barra inferior;
  - estado sem modo cai para tela inicial.
- Versionamento atualizado para v2.3.19.2.

## Validação
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
- `bash -n iniciar-terra-nova-bazzite.sh`
