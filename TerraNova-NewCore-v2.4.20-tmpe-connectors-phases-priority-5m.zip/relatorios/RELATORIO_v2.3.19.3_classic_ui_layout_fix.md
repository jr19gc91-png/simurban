# RELATORIO v2.3.19.3 - Classic UI Layout Fix

## Objetivo

Corrigir a interface quebrada do SIMURB / Terra Nova preservando o ambiente moderno do NewCore. Esta rodada ficou limitada a UI, fluxo visual e versionamento.

## Arquivos alterados

- `index.html`
- `styles/newcore.css`
- `src/ui/UISystem.js`
- `src/main.js`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `package.json`
- `README.md`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`
- `relatorios/RELATORIO_v2.3.19.3_classic_ui_layout_fix.md`

## Causa provavel

O CSS acumulava blocos de varias versoes antigas que competiam entre si: regras de painel direito, minimapa, dock de informacoes, submenu lateral, bottombar com `min-width` alto e submenus com largura minima fixa. O JS tambem misturava `this.flow` com `state.mode`, aplicando classes de modo no fim do `render()` sem uma funcao unica de estado visual. Isso permitia estados hibridos e deixava a UI sensivel a ordem de renderizacao.

## O que foi corrigido

- Criada `setAppMode(mode)` em `src/ui/UISystem.js`, aceitando somente `start`, `generator` e `city`.
- `setAppMode()` remove sempre todas as classes de modo antes de aplicar a classe nova.
- Trocas de modo fecham menu hamburguer e submenus ativos.
- `start-mode` mostra somente tela inicial e esconde gerador/HUD.
- `generator-mode` mostra somente o painel do gerador e esconde HUD da cidade.
- `city-mode` mostra topbar, lateral esquerda e barra inferior; tela inicial e gerador ficam escondidos.
- Submenus de ferramentas foram reposicionados acima da barra inferior com `position: fixed`, `left: 272px`, `right: 10px`, `bottom: 78px`, `max-height: 154px` e sem overflow vertical.
- Bottombar passou a respeitar a viewport real com `left/right: 10px`, `min-width: 0`, largura automatica e tool buttons compactos.
- Lado direito do modo cidade fica vazio: dock de informacoes, painel moderno, minimapa, TMPE externo, pill e atalhos fixos foram escondidos neste modo.
- A lateral esquerda foi mantida apenas para dashboards: Relatorios, Linhas, Economia, Trafego, Populacao, Transporte e Graficos.
- Adicionado favicon `data:` para evitar 404 de favicon durante validacao.
- Cache-busting dos launchers atualizado para `v23193`.

## O que nao foi alterado

- Ambiente/terreno/render moderno do NewCore.
- Three.js/vendor.
- RoadCore.
- Veiculos, IA, economia, buildings, mapa procedural e trafego.
- Servidor anti-cache `tools/serve_no_cache.py`.

## Versionamento

- `NEWCORE_VERSION`: `TerraNova-NewCore-v2.3.19.3-classic-ui-layout-fix`
- `GAME_SCHEMA_VERSION`: `newcore-save-v2.3.19.3`
- `package.json`: `2.3.19.3`
- Textos visiveis do HTML e launchers atualizados para v2.3.19.3.

## Validacoes feitas

- `node tools/check-js.mjs`: o binario `node` nao existe no PATH deste Windows. Foi feita validacao equivalente via runtime Node do Codex com `vm.SourceTextModule`: 34 modulos JS parseados, 0 erros de sintaxe.
- `node tools/audit-modules.mjs`: o binario `node` nao existe no PATH deste Windows. Foi feita auditoria equivalente: 34 modulos, 9354 linhas, maior modulo com 1140 linhas, nenhum modulo acima de 1200 linhas e nenhum `game.js` monolitico na raiz.
- `bash -n iniciar-terra-nova-bazzite.sh`: tentado via PowerShell, WSL, Git/MSYS/Cygwin comuns. Nao havia Bash funcional; WSL existe, mas sem distribuicao instalada. O script foi inspecionado e so recebeu alteracoes de texto de versao/cache-busting.
- Servidor anti-cache local iniciado com `tools/serve_no_cache.py`.
- Chrome headless do sistema em 1366x768:
  - abertura inicial em `start-mode`;
  - `Novo mapa` troca para `generator-mode`;
  - gerador nao mostra HUD da cidade;
  - `Iniciar cidade neste mapa` troca para `city-mode`;
  - topbar, lateral esquerda e bottombar aparecem no modo cidade;
  - tela inicial e gerador ficam escondidos no modo cidade;
  - lado direito sem dock, minimapa ou painel fixo;
  - submenu de Estradas abre compacto acima da bottombar;
  - submenu de Trilhos abre compacto acima da bottombar;
  - bottombar e submenus nao ficam fora da viewport;
  - console sem erros apos favicon `data:`.

## Pendencias restantes

- Rodar literalmente `bash -n iniciar-terra-nova-bazzite.sh` em um Linux/Bazzite ou em Windows com Bash instalado.
- Em 1366x768, a topbar prioriza os primeiros status e oculta alguns indicadores de menor prioridade para evitar corte horizontal.
