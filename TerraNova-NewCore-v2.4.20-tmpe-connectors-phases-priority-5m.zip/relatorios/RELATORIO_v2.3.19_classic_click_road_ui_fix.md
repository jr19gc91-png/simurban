# RELATÓRIO v2.3.19 - Classic Click / Road UI Fix

## Objetivo
Corrigir dois bloqueios críticos reportados pelo usuário:
1. segundo clique de construção de estradas/trilhos falhando;
2. submenus de ferramentas grandes demais e ainda com comportamento de painel/modal.

## Alterações
- `src/systems/RoadSystem.js`
  - construção linear agora não bloqueia por inclinação/relevo do terreno procedural;
  - mantém bloqueio apenas para segmentos muito curtos ou duplicados;
  - mensagem de erro ficou honesta: curto/duplicado, não água/inclinação.
- `src/systems/InputController.js`
  - mantém construção de estrada/trilho no `pointerdown`;
  - adiciona fallback de raycast no plano quando a bisseção com terreno falhar;
  - garante que `tool-panel` seja tratado como UI e o canvas continue livre no resto da tela.
- `styles/newcore.css`
  - submenus de ferramentas viraram bandeja compacta acima da barra inferior;
  - remove visual de painel grande;
  - reduz altura, textos, grupos e botões no modo cidade.

## Observação
Se o navegador ainda mostrar `v2.3.17.2`, é versão/cache antigo. Extrair o ZIP novo em pasta limpa e dar hard refresh.
