# RELATÓRIO v2.3.20 - Classic Tools / Road Grid Fix

## Base
Partiu de `TerraNova-NewCore-v2.3.19.3-classic-ui-layout-fix.zip`, usando o `.md` oficial e o jogo antigo modularizado como referência de fluxo.

## Correções aplicadas
- Construção de estradas e trilhos:
  - `pointerdown` agora roda em fase de captura para vencer o OrbitControls;
  - `stopImmediatePropagation` evita a câmera roubar clique durante construção;
  - botão direito finaliza a construção: cria o último trecho se houver nó pendente e limpa o preview/nó pendente;
  - menu de contexto é bloqueado enquanto estrada/trilho estão ativos.
- Câmera:
  - zoom mínimo reduzido para permitir aproximar mais;
  - distância máxima ampliada;
  - WASD/setas invertidos para voltar ao comportamento esperado do city builder/versão antiga.
- Zoneamento:
  - estradas térreas zoneáveis agora geram `zoneGrid` visual automático em até 4 células de profundidade por lado;
  - grid neutro não cria prédio sozinho; serve como base visual para a ferramenta de zoneamento.
- Estradas/cruzamentos:
  - adicionado patch central em nós e cruzamentos para cobrir frestas pretas;
  - flares de aproximação maiores para reduzir as emendas quebradas.
- Save/state:
  - `zoneGrid` adicionado ao estado e preservado em import/export.

## Arquivos alterados
- `src/systems/InputController.js`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `src/game/GameShell.js`
- `src/systems/RoadSystem.js`
- `src/systems/ZoningSystem.js`
- `src/roads/RoadIntersections.js`
- `index.html`
- `package.json`
- `README.md`
- launchers `.bat` e `.sh`

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`

## Pendências
- Refinar geometria de cruzamentos para continuidade perfeita de faixa.
- Criar conversão de `zoneGrid` para zonas pintadas por célula, em vez de continuar gerando lotes por segmento.
- Comparar pixel a pixel a UI antiga após estabilizar o fluxo de construção.
