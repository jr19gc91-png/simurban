# RELATÓRIO v2.3.21 - Controls / Road Grid / UI Fix

## Base
Partiu da `TerraNova-NewCore-v2.3.20-classic-tools-road-grid-fix.zip`.

## Correções aplicadas
- WASD e setas ajustados para o padrão do jogo antigo: W/↑ avança na direção da câmera, S/↓ recua, A/D e setas laterais deslocam lateralmente sem inverter.
- Zoom mínimo reduzido para permitir aproximar mais a câmera.
- Submenus das ferramentas compactados e travados acima da barra inferior, sem ocupar metade da tela.
- Leitura de nível removida visualmente dos submenus; PageUp/PageDown seguem funcionando.
- Grid de zoneamento corrigido: rotação do mesh agora usa eixo Y, não Z; isso remove células tortas/losangos quebrados.
- Grid de zoneamento ficou menos agressivo perto de cruzamentos e segue 4 células de profundidade por lado em vias zoneáveis de nível 0.
- Cruzamentos/curvas: removido guia escuro que criava manchas/triângulos pretos; aumentada sobreposição do asfalto nas interseções e removido disco central em nós simples.
- Clique direito continua concluindo/cancelando o traçado atual de estrada/trilho.

## Arquivos alterados
- `src/map/MapGenerator.js`
- `src/roads/RoadIntersections.js`
- `src/systems/ZoningSystem.js`
- `src/systems/InputController.js`
- `styles/newcore.css`
- `index.html`
- `README.md`
- `package.json`
- `src/game/GameState.js`

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`

## Pendências
- Continuidade perfeita das faixas dentro de cruzamentos ainda exige refactor dedicado do RoadRenderer/RoadIntersections.
- Ferramenta antiga 100% fiel ainda depende de transpor a lógica exata do `game.original.js` em uma camada ClassicToolAdapter.
