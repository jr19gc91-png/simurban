# RELATÓRIO — TerraNova-NewCore v2.3.2 Flow/Road/Vehicle Fix

## Base
- Base direta: `TerraNova-NewCore-v2.3.1-flow-road-ui-fix`.
- Linha oficial preservada: v2.2.2 Bazzite como base funcional, com shell v3.3 apenas como referência visual.

## Objetivo da rodada
Corrigir os pontos apontados no teste visual:
1. Separar tela inicial, gerador de mapas e interface de cidade.
2. Parar a mistura da UI de cidade com o gerador.
3. Refinar sinalização das vias.
4. Corrigir tráfego de veículos nas faixas e no sentido correto.

## Alterações implementadas

### Fluxo de telas
- Adicionada tela inicial `startScreen` com ações:
  - `Gerador de mapas`.
  - `Cidade rápida`.
- Criadas classes de fluxo no `body`:
  - `start-mode`.
  - `generator-mode`.
  - `city-mode`.
- No modo gerador, a UI de cidade fica escondida:
  - barra inferior;
  - painel de construção;
  - TMPE;
  - dock de relatórios;
  - minimapa;
  - botão de atalhos.
- No modo cidade, o gerador fica escondido para evitar sobreposição.
- `Voltar ao gerador` agora emite atualização de estado corretamente.

Arquivos principais:
- `index.html`
- `styles/newcore.css`
- `src/ui/UISystem.js`
- `src/game/GameShell.js`

### Vias e sinalização
- Removidas as faixas tracejadas brancas das bordas externas da pista.
- Mantidas bordas/curbs escuros para leitura da estrada sem poluir a pista.
- Setas reduzidas em tamanho e frequência.
- Bordas brancas internas foram afinadas.

Arquivos principais:
- `src/roads/RoadRenderer.js`
- `src/roads/RoadMarkings.js`

### Veículos: faixa e direção
- Corrigido o deslocamento lateral dos veículos:
  - em mão dupla, os veículos agora usam sempre o lado correto relativo ao heading real da rota;
  - removido o comportamento anterior que alternava lado por seno/random e podia jogar carros na faixa oposta;
  - ônibus/serviço usam faixas coerentes quando a classe do segmento pede isso;
  - jitter lateral pequeno mantido apenas para não ficar robótico.
- Corrigido fallback de tráfego em vias mão dupla:
  - antes os caminhos gerados sem origem/destino só trafegavam A→B;
  - agora vias mão dupla geram também rota reversa B→A.
- Corrigido fallback de ônibus para evitar compor rotas com segmentos desconectados.

Arquivo principal:
- `src/systems/VehicleSystem.js`

### Versionamento
- `package.json`: `2.3.2`.
- `GAME_SCHEMA_VERSION`: `newcore-save-v2.3.2`.
- `NEWCORE_VERSION`: `TerraNova-NewCore-v2.3.2-flow-road-vehicle-fix`.
- Textos atualizados em `README.md`, `index.html` e scripts.

## Validação executada
```bash
bash -n iniciar-terra-nova-bazzite.sh
node tools/check-js.mjs
node tools/audit-modules.mjs
node tools/smoke-newcore.mjs
```

Resultado:
```txt
checked=34
modules=34 totalLines=8497 maxModuleLines=1158
maior módulo: src/systems/RoadSystem.js com 1158 linhas
```

Smoke test:
```txt
Playwright não encontrado. Smoke test NÃO executado.
exit=2
```

## Observação honesta
A correção de veículos nesta rodada é o básico correto para faixa/sentido no NewCore atual. Ainda não é TMPE faixa-a-faixa real com conectores por aproximação. Isso deve ficar para uma rodada dedicada de LaneSystem/TMPE.
