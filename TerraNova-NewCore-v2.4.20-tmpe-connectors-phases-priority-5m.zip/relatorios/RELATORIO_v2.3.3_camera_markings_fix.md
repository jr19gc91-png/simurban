# RELATÓRIO v2.3.4 - Tool Submenus

## Objetivo
Aplicar dois ajustes pedidos pelo usuário sobre a base v2.3.2:
1. remover as listras brancas exageradas nos nós/interseções;
2. aproximar os controles de câmera do padrão Cities Skylines 1.

## Alterações
- `src/roads/RoadIntersections.js`
  - removidas as zebras/crosswalks brancas geradas automaticamente em interseções;
  - mantidas apenas guias sutis de aproximação para leitura de faixa.
- `src/map/MapGenerator.js`
  - câmera ajustada para: botão direito gira, botão do meio move e roda faz zoom;
  - botão esquerdo fica livre para construção/seleção;
  - adicionados atalhos de navegação `WASD`/setas para mover e `Q/E` para girar, em estilo city builder;
  - desabilitado menu de contexto no canvas para o arraste com botão direito funcionar sem interrupção.
- `src/game/GameState.js`
  - schema atualizado para `newcore-save-v2.3.4`.
- Metadados/versionamento atualizados em `index.html`, `README.md`, `package.json` e `MapGenerator.js`.

## Validação esperada
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
