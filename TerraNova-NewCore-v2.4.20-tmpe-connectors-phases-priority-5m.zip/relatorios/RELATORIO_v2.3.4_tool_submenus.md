# RELATÓRIO v2.3.4 - Tool Submenus

## Objetivo
Adaptar o funcionamento da UI antiga (`03_TerraNova-NewCore-v3.3-game-ui-shell`) ao jogo atual sem substituir renderer, RoadCore, gerador, economia ou sistemas reais.

## Implementado
- A barra inferior continua como seletor principal de ferramentas.
- O painel lateral direito agora funciona como submenu único por ferramenta, no estilo da UI antiga:
  - Sem ferramenta ativa
  - Estradas
  - Trilhos
  - Estação
  - Linha de trilho
  - Zoneamento
  - Parada de ônibus
  - Linha de ônibus
  - Melhorar via
  - Tráfego / mini-TMPE
  - Demolir
  - Inspecionar
- Removida a mistura anterior onde o painel direito mostrava opções de estrada, zona, transporte, estatísticas e TMPE ao mesmo tempo.
- O mini-TMPE foi integrado ao mesmo painel lateral direito, em vez de abrir como painel separado.
- Adicionado botão `×` no painel direito para cancelar ferramenta.
- O submenu `Melhorar via` ganhou controles próprios para faixas, velocidade, direção e classe do segmento.
- Estatísticas foram distribuídas por contexto: zoneamento, ônibus, trilhos, inspeção etc.

## Arquivos alterados
- `index.html`
- `styles/newcore.css`
- `src/ui/UISystem.js`
- `src/game/GameState.js`
- `src/map/MapGenerator.js`
- `package.json`
- `README.md`

## Validação
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
- `bash -n iniciar-terra-nova-bazzite.sh`

## Observação
O submenu de trilhos ainda informa que trilhos elevados/subterrâneos ferroviários não estão implementados nesta base. Não foi criada feature fake.
