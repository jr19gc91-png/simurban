# RELATÓRIO v2.3.5 - Visual Refine

## Base
`TerraNova-NewCore-v2.3.4-tool-submenus.zip`

## Objetivo
Refinar visual sem mexer pesado em RoadCore, simulação, ferramentas ou estrutura da UI.

## Alterações principais
- UI/HUD com glass mais limpo, contraste melhor e botões menos “chapados”.
- Barra inferior refinada com hover/active mais profissional.
- Painel lateral direito com hierarquia visual melhor para os submenus únicos por ferramenta.
- Tela inicial e gerador com acabamento mais premium.
- Minimap e painéis de dados com bordas/sombras mais suaves.
- Vignette sutil no modo cidade/gerador para dar leitura cinematográfica sem bloquear cliques.
- Estradas com asfalto menos lavado, meio-fio menos claro e sinalização menos estourada.
- Faixas/setas ficaram mais finas e discretas.
- Zonas ficaram menos opacas para não poluir a leitura do terreno.
- Luz/fog ajustados para reduzir estouro visual.
- Paletas dos edifícios ajustadas para tons menos saturados e mais naturais.

## Arquivos alterados
- `styles/newcore.css`
- `src/utils/Materials.js`
- `src/roads/RoadMaterials.js`
- `src/map/MapGenerator.js`
- `src/systems/BuildingSystem.js`
- `src/game/GameState.js`
- `index.html`
- `README.md`
- `package.json`

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
