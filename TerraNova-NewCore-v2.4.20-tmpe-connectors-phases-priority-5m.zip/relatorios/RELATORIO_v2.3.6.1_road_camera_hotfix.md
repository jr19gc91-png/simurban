# RELATÓRIO v2.3.6.1 - Road / Camera Hotfix

## Objetivo
Aplicar hotfix visual sobre a base v2.3.6 para:
1. reduzir o aspecto de estrada quebrada / rachada nos nós;
2. ajustar a câmera para permitir inclinação ao clicar/arrastar o scroll do mouse.

## Alterações
- `src/roads/RoadIntersections.js`
  - ampliado o hull base e o hull de superfície das interseções;
  - adicionado `centerCap` asfaltado no centro dos nós para cobrir fissuras escuras;
  - aumentadas as peças de transição (`flare`) para sobrepor melhor os segmentos e suavizar emendas.
- `src/map/MapGenerator.js`
  - clique/arrasto do scroll (`MIDDLE`) agora usa rotação/orbit, permitindo inclinação vertical da câmera;
  - botão direito continua girando/orbitando;
  - WASD/QE permanecem ativos.
- `src/game/GameState.js`
  - schema atualizado para `newcore-save-v2.3.6.1`.
- versionamento atualizado em `index.html`, `README.md`, `package.json` e `MapGenerator.js`.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
- `node tools/smoke-newcore.mjs` -> SKIPPED se Playwright ausente.
