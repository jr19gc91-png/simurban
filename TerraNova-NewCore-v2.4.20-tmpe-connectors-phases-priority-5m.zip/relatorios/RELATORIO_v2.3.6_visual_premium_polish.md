# RELATÓRIO v2.3.6 - Visual Premium Polish

## Base

`TerraNova-NewCore-v2.3.5-visual-refine.zip`

## Objetivo

Aprofundar o acabamento visual do jogo sem reescrever arquitetura, sem quebrar o fluxo tela inicial/gerador/cidade e sem mexer pesado na lógica de RoadCore/IA.

## Arquivos alterados

- `styles/newcore.css`
- `src/utils/Materials.js`
- `src/roads/RoadMaterials.js`
- `src/roads/RoadMarkings.js`
- `src/roads/RoadIntersections.js`
- `src/map/MapGenerator.js`
- `src/systems/BuildingSystem.js`
- `src/systems/VehicleSystem.js`
- `src/game/GameState.js`
- `index.html`
- `README.md`
- `package.json`

## Mudanças principais

### UI / HUD

- Aplicado polimento visual premium no HUD.
- Topbar, bottombar, painel direito, minimapa, dock e tela inicial receberam melhor contraste, bordas mais suaves, sombras mais controladas e estados hover/ativo mais claros.
- Mantido o comportamento: barra inferior escolhe a ferramenta e o painel direito mostra um submenu único por ferramenta.

### Estradas

- Asfalto ajustado para cor mais natural e menos lavada.
- Marcações brancas e amarelas ficaram mais finas e menos opacas.
- Setas reduzidas e menos repetidas.
- Removidas linhas brancas externas de borda da pista.
- Guias de aproximação em cruzamentos foram suavizadas.
- Mantida a regra: sem zebras brancas gigantes e sem tracejado nas bordas externas.

### Terreno / água / luz

- Exposição, luz hemisférica, sol e fog ajustados para reduzir excesso de brilho.
- Água recebeu cor mais profunda e menos chapada.
- Texturas de terreno/grama tiveram base levemente mais natural.

### Edifícios

- Paletas de paredes/telhados/comércios/indústrias foram suavizadas.
- Adicionado acabamento procedural leve: plinto/base, frisos, cantos, faixas de fachada e pequenos pisos de quintal em residenciais.
- Não foi criado sistema novo de edifícios.

### Veículos

- Cores dos carros ficaram menos saturadas.
- Carros, serviços e ônibus ganharam rodas e faróis/lanternas simples.
- Ônibus e trens tiveram vidro/faixa com proporção mais limpa.
- Não foi alterada a lógica de tráfego nesta rodada.

## Versionamento

- `NEWCORE_VERSION`: `TerraNova-NewCore-v2.3.6-visual-premium-polish`
- `GAME_SCHEMA_VERSION`: `newcore-save-v2.3.6`
- `package.json`: `2.3.6`

## Validação executada

```bash
bash -n iniciar-terra-nova-bazzite.sh
node tools/check-js.mjs
node tools/audit-modules.mjs
node tools/smoke-newcore.mjs
```

Resultado:

- `bash -n`: OK
- `check-js`: OK, `checked=34`
- `audit-modules`: OK, `modules=34`, `maxModuleLines=1158`
- `smoke-newcore`: SKIPPED, Playwright não encontrado no ambiente

## Pendências honestas

- QA visual com navegador real ainda deve ser feito pelo usuário/Codex/Claude com screenshot.
- IA de faixas/direção dos veículos ainda merece rodada própria.
- TMPE real faixa-a-faixa ainda não está implementado.
