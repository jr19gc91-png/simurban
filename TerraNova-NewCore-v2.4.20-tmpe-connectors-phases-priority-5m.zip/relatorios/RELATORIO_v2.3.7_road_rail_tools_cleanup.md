# RELATÓRIO v2.3.7 - Road / Rail Tools Cleanup

## Objetivo
Corrigir falhas/obstruções na construção e aproximar as ferramentas de estrada/trilho do comportamento antigo, mantendo a UI atual com submenu único por ferramenta.

## Implementado
- Regra de obra: ao construir estrada ou trilho, árvores, rochas e detalhes naturais dentro do corredor da construção são removidos do mapa.
- `MapGenerator` agora marca grupos naturais (`natural-trees`, `natural-rocks`, `natural-details`) e expõe `clearNaturalObstaclesAlongPath`.
- Ferramenta Estrada ganhou tipo:
  - rua;
  - avenida.
- Avenida agora é salva como `kind: 'avenue'` e renderiza canteiro central visual quando for mão dupla.
- Ferramenta Estrada mantém:
  - mão dupla;
  - mão única;
  - suave/reto;
  - faixas 1-5;
  - velocidade;
  - nível;
  - classe de segmento.
- Ferramenta Trilho ganhou submenu próprio com:
  - trilho simples;
  - trilho duplo;
  - suave/reto;
  - velocidade;
  - nível.
- Trilhos agora armazenam `kind`, `geometry`, `speedKmh` e `elevation` conforme configuração da ferramenta.
- Versionamento atualizado para v2.3.7 / `newcore-save-v2.3.7`.

## Observação
Avenida e trilhos já têm configuração e renderização básica. TMPE faixa-a-faixa real e pathfinding ferroviário avançado ainda merecem rodada própria.

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`
