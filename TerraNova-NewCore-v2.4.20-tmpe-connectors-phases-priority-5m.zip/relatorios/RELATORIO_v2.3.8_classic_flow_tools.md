# RELATÓRIO v2.3.8 - Classic Flow Tools

## Objetivo
Aproximar a interface e as ferramentas do modo antigo, mantendo a base NewCore v2.3.7.

## Alterações principais

### Fluxo separado
- Tela inicial agora funciona como **Novo Jogo**.
- Fluxo explícito:
  1. Novo Jogo
  2. Gerador de Mapas
  3. Cidade/Jogo
- No modo gerador, HUD de cidade, barra de ferramentas, minimapa e painel direito ficam ocultos.
- No modo cidade, o gerador fica oculto.

### Interface estilo antigo
- Topbar recebeu botão hambúrguer e layout mais próximo do shell antigo.
- Criado menu rápido com:
  - Novo mapa
  - Salvar JSON
  - Carregar JSON
  - Limpar cidade
  - Voltar ao Novo Jogo
- Barra inferior passou a trabalhar por categorias:
  - Estradas
  - Trilhos
  - Transporte
  - Zoneamento
  - Terreno
  - Demolir
  - Editar via
  - TMPE
  - Inspecionar
- Criado painel esquerdo clássico com abas:
  - Relatórios
  - Linhas
  - Economia
  - Tráfego

### Ferramentas
- Estradas ganhou presets rápidos:
  - Rua local
  - Rua principal
  - Avenida
  - Mão única
- Trilhos ganhou presets rápidos:
  - Trilho simples
  - Trilho duplo
  - Superfície
  - Elevado +1
- Transporte virou categoria própria, com subferramentas:
  - Parada bus
  - Linha bus
  - Estação
  - Linha trilho
- Terreno virou categoria própria, apontando para o Gerador de Mapas.

### Mantido da v2.3.7
- Limpeza de árvores/rochas/detalhes no corredor de obras de estrada e trilho.
- Avenida com canteiro central visual.
- Mão única/mão dupla.
- Trilho simples/duplo.
- Submenus únicos por ferramenta/categoria.

## Arquivos alterados
- `index.html`
- `styles/newcore.css`
- `src/ui/UISystem.js`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `README.md`
- `package.json`

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`

Smoke test segue dependente de Playwright no ambiente.
