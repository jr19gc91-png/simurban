# RELATÓRIO v2.3.9 - Classic Road / Intersections

## Objetivo
Continuar a v2.3.8 aproximando ferramentas e interface do modo antigo, com primeira rodada de polimento real em vias, interseções e tráfego por faixa.

## Alterações principais
- Adicionado preset **Terra** na ferramenta de estrada.
- RoadSystem agora aceita `kind = dirt`.
- Estrada de terra força 1 faixa, velocidade baixa e não gera calçada/marcações.
- Adicionado material/textura procedural de estrada de terra.
- Avenida mantém canteiro central visual e recebeu reforço de renderização.
- Interseções receberam guia central sutil, flares mais longos e material compatível com terra/asfalto.
- Veículos agora recalculam faixa desejada ao trocar de segmento e fazem transição lateral gradual, reduzindo teleporte de faixa.
- Mantida regra de limpeza automática de árvores, rochas e detalhes naturais no corredor de obra para estrada/trilho.

## Arquivos alterados
- `index.html`
- `README.md`
- `package.json`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `src/utils/Materials.js`
- `src/systems/RoadSystem.js`
- `src/roads/RoadRenderer.js`
- `src/roads/RoadMarkings.js`
- `src/roads/RoadIntersections.js`
- `src/systems/VehicleSystem.js`
- `src/ui/UISystem.js`

## Validação
- `bash -n iniciar-terra-nova-bazzite.sh`
- `node tools/check-js.mjs`
- `node tools/audit-modules.mjs`

## Pendências
- TMPE faixa-a-faixa real ainda precisa de rodada própria.
- Conversões por faixa em cruzamentos ainda são aproximadas.
- Rotatória automática ainda não implementada.
