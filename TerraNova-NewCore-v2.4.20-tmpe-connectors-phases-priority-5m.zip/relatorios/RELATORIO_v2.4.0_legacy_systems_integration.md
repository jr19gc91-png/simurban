# RELATORIO v2.4.0 - Legacy Systems Integration

## Objetivo

Transformar o NewCore na nova versao jogavel do SIMURB antigo, usando o renderer/mapa moderno como casca e integrando comportamento, layout, regras, trafego, transporte, economia, RCI, TMPE, save/load e UI funcional do projeto antigo modular.

## Resultado

A v2.4.0 entrega o NewCore como a nova linha principal do jogo antigo. O jogo abre na tela inicial, separa gerador e cidade, preserva o MapGenerator, mantem o RoadCore modular e executa os fluxos centrais de cidade com HUD classica adaptada.

Foi adicionada uma iluminacao/atmosfera nova do proprio NewCore: ciclo dia/noite cinematografico, clima dinamico, ceu procedural, sol visivel, lua, nuvens e chuva. A iluminacao antiga continua ignorada.

## Arquivos alterados

- `README.md`
- `index.html`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`
- `styles/newcore.css`
- `src/map/MapGenerator.js`
- `src/game/GameState.js`
- `src/game/GameShell.js`
- `src/systems/InputController.js`
- `src/systems/ZoningSystem.js`
- `src/systems/VehicleSystem.js`
- `src/systems/SimulationSystem.js`
- `src/roads/RoadRenderer.js`
- `src/ui/InfoPanels.js`
- `src/ui/UISystem.js`

## Arquivos criados

- `src/legacy/LegacyConstants.js`
- `src/systems/EventSystem.js`
- `src/map/AtmosphereSystem.js`
- `relatorios/AUDITORIA_LEGACY_INTEGRATION_v2.4.0.md`
- `relatorios/RELATORIO_v2.4.0_legacy_systems_integration.md`

## Sistemas antigos integrados

- Ferramentas e atalhos classicos.
- UI antiga adaptada: dock lateral, paineis de dados, topbar de HUD e barra inferior de ferramentas.
- Regras de grade RCI: celula de 20 m, ate 4 fileiras por via zoneavel.
- Zoneamento residencial/comercial/industrial conectado a estradas.
- RoadCore modular com rua, avenida, mao unica, curva, intersecoes e niveis.
- Trafego por sentido/faixa, com respeito a mao unica e classes de faixa.
- TMPE: semaforos, pare/preferencial e classes de faixa/segmento.
- Transporte por onibus: paradas, linhas, frota e metricas.
- Sistema ferroviario: trilho duplo, estacoes, linhas e trens.
- Economia/RCI: demanda, populacao, empregos, impostos, custos, passageiros/h, congestionamento e historico.
- Save/load JSON.
- Incidentes operacionais leves por segmento, inspirados no sistema antigo.

## Sistemas ignorados

- Iluminacao antiga.
- Sky antigo.
- Atmosfera/fog antigo.
- Setup de renderer, shadows e tone mapping antigo.
- Monolito `game.js`.
- Copia integral de `game.original.js`.
- Assets externos obrigatorios.
- Dependencias de internet/CDN.

## Confirmacao sobre iluminacao

Confirmado: a iluminacao antiga NAO foi integrada. A atmosfera atual e nova, modular e propria do NewCore (`src/map/AtmosphereSystem.js`), desenhada para combinar com o renderer/mapa moderno.

## Launchers

- `iniciar-terra-nova-windows.bat` preservado e atualizado para `v2.4.0 - Legacy Systems Integration`.
- `iniciar-terra-nova-bazzite.sh` preservado e atualizado para `v2.4.0 - Legacy Systems Integration`.
- Cache-bust atualizado para `v240`.

## Comandos/validacoes executados

- `node_repl` com `vm.SourceTextModule`: parse ESM dos modulos `src/` sem erros.
- Auditoria de tamanho/modularidade via script Node no `node_repl`.
- `rg` para versionamento, proibicoes, imports antigos e arquivos obrigatorios.
- Servidor local Python `tools/serve_no_cache.py` em portas temporarias.
- Playwright/Chrome headless smoke:
  - `http://127.0.0.1:8147/?cache=smoke-v240`
  - `http://127.0.0.1:8148/?cache=atmos-v240`
  - `http://127.0.0.1:8149/?cache=final-v240`
- Screenshot/pixel check via Playwright + Python/Pillow.

## Resultado do smoke final

- Versao: `TerraNova-NewCore-v2.4.0-legacy-systems-integration`.
- Tela inicial: OK.
- Gerador separado da HUD: OK.
- Cidade com HUD separada: OK.
- Estradas: 22 segmentos, 21 nos.
- Trilhos: 1 segmento.
- Zoneamento: 43 lotes, 525 celulas de grade.
- Predios: 38.
- Veiculos: 21.
- Onibus ativos: 2.
- Trem ativo: 1.
- TMPE: 1 semaforo.
- Eventos/incidentes: sistema ativo.
- Save/load JSON: round-trip OK.
- Clima/HUD: OK, exemplo `☀ Limpo 30°C`.
- Atmosfera: grupo renderizado.
- Console fatal: nenhum `pageerror` ou `console.error`.

## QA manual esperado/documentado

1. Abrir o jogo pelo launcher.
2. Ver tela inicial.
3. Clicar Novo mapa.
4. Gerar mapa.
5. Entrar na cidade.
6. Confirmar que a UI do gerador nao aparece misturada com a HUD da cidade.
7. Construir uma rua reta bidirecional.
8. Construir uma avenida.
9. Construir uma via de mao unica.
10. Construir curva.
11. Construir cruzamento T.
12. Construir cruzamento X.
13. Pintar zoneamento residencial/comercial/industrial.
14. Esperar surgirem predios.
15. Verificar frente dos predios para a rua.
16. Criar paradas de onibus.
17. Criar linha de onibus.
18. Ver onibus seguindo faixa/sentido correto.
19. Criar trilho duplo.
20. Criar estacao.
21. Criar linha ferroviaria.
22. Ver trem trafegando.
23. Testar PageUp/PageDown.
24. Criar elevado.
25. Criar tunel/nivel negativo, se suportado pela ferramenta atual.
26. Testar TMPE/faixa de onibus.
27. Testar save/export JSON.
28. Recarregar save.
29. Verificar HUD: dinheiro, populacao, empregos, passageiros/h, congestionamento.
30. Conferir FPS aceitavel em 1366x768 e 1920x1080.
31. Observar ciclo dia/noite, sol visivel, lua, nuvens, chuva e mudanca de clima.

## Bugs conhecidos

- `node`, `git` e `bash` nao estao no PATH deste PowerShell; validacoes equivalentes foram feitas com `node_repl`, Playwright, Python e inspecao estatica.
- WSL esta presente apenas como stub sem distro funcional, entao `bash -n` do Bazzite nao foi executado.
- O clima dinamico ainda nao possui painel para selecao manual de clima.
- FPS real em 1920x1080 precisa ser medido na maquina alvo pelo QA manual.

## Proximos passos recomendados

- Automatizar PageUp/PageDown, elevado/tunel e linhas manuais em Playwright.
- Criar painel opcional de clima/tempo para QA e debug.
- Expandir eventos com veiculos de servico e resposta operacional.
- Adicionar graficos especificos de clima e incidentes nos paineis laterais.
