# Terra Nova / NewCore v2.4.10 — Hotfix renderização de estradas em escala 5m/u

## Problema observado
Após a migração para escala oficial **1 unidade = 5 metros**, a via era criada, mas aparecia como uma fita/placa escura sem detalhes, marcações, calçadas ou leitura correta do renderer.

## Causa principal
`src/roads/RoadMarkings.js` usava a função de escala `m(...)`, mas não importava `m` de `src/utils/Scale.js`.

Resultado: na primeira chamada de renderização de desgaste/marcações da estrada ocorria `ReferenceError: m is not defined`, interrompendo o render do restante das camadas visuais da via. O asfalto/base já tinha sido criado, por isso aparecia apenas o bloco simples.

## Correções aplicadas
- Adicionado `import { m } from '../utils/Scale.js';` em `RoadMarkings.js`.
- Ajustados restos de medidas físicas em `RoadMarkings.js` para escala 5m/u:
  - largura de overlays de faixa;
  - marcações de ônibus/bike/estacionamento;
  - ticks de estacionamento;
  - carros estacionados;
  - comprimentos mínimos de trecho;
  - dash/gap internos.
- Ajustados restos de medidas físicas em `RoadRenderer.js`:
  - bordas de via;
  - pilares/portais/ghost de túnel;
  - taper mínimo;
  - thresholds de afunilamento.
- Atualizado versionamento para `v2.4.10`.

## O que esta versão NÃO tenta resolver ainda
Este é um hotfix para recuperar renderização das vias na escala 5m/u. Ainda ficam para próximas etapas:
- cruzamento brasileiro mais fiel;
- afunilamento funcional completo;
- motos/corredor;
- centro de faixa dos veículos com validação visual;
- zoneamento sem sobreposição em todos os casos;
- rampas/elevados mais robustos.

## Validação executada
- `npm run check` ✅ `checked=37`
- `npm run audit` ✅ maior módulo: `1194` linhas
- `bash -n iniciar-terra-nova-bazzite.sh` ✅

## Pacote
`TerraNova-NewCore-v2.4.10-road-render-hotfix-5m.zip`
