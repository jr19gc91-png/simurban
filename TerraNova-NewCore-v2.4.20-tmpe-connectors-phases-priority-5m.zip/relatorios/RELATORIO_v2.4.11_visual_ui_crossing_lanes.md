# Terra Nova / NewCore v2.4.11 — Visual UI, cruzamentos e faixas em 5m/u

## Objetivo
Retomar os ajustes visuais após a mudança oficial para 1 unidade = 5 metros, sem voltar a quebrar a renderização das vias.

## Correções aplicadas

### UI de ferramentas mais compacta
- Painel de ferramentas reduzido de largura total para um painel compacto no canto inferior esquerdo.
- Botões e grupos internos menores.
- Labels curtos para evitar texto cortado.
- Ferramenta de estradas agora mostra os grupos em grade 2 colunas compacta.
- Mantido sem barra de rolagem no desktop.

### Barra inferior mais baixa
- Botões Pausar / Ciclo / 1× / 3× / 5× reduzidos.
- Botões principais da barra inferior reduzidos.

### Minimapa forçado
- Minimapa agora é forçado via CSS e JS no modo cidade para evitar overrides antigos que o escondiam.
- Posição: canto direito inferior, acima da barra inferior.

### Cruzamentos em escala 5m/u
- Corrigidos valores de faixa de pedestres que ainda estavam em unidades brutas.
- Faixas de pedestre ficaram menores e mais proporcionais à escala 5m/u.
- Linha de retenção/parada reposicionada.
- Semáforos reposicionados com valores convertidos para metros.
- Adicionada marca central amarela tipo caixa/guia BR para cruzamentos de 4 braços.

### Veículos no centro das faixas
- Reduzido jitter lateral dos veículos.
- Offset de veículos em vias bidirecionais agora usa `layout.centerLineOffset` + centro da faixa, em vez de deslocamento fixo herdado.

### Terra / vias quebradas
- Preset de rua de terra agora usa geometria `smooth` para aceitar curvas.
- Renderer mantém rua de terra sem marcações de asfalto/faixas/setas.

## Validação
- `npm run check` OK — 37 módulos JS parseados.
- `npm run audit` OK — maior módulo 1194 linhas.
- `bash -n iniciar-terra-nova-bazzite.sh` OK.

## Ainda pendente para próximas etapas
- Afunilamento geométrico mais real entre larguras diferentes.
- Motos e corredor.
- Cruzamento BR ainda pode ser refinado com ilha/refúgio, faixa contínua e sinalização por sentido.
- Zoneamento pode precisar de um filtro visual extra por bounding box se o problema persistir em cidades já salvas.
