# Terra Nova / SIMURB NewCore v2.4.12 - Legacy RoadCore Transplant 5m/u

## Entrega

- ZIP alvo: `TerraNova-NewCore-v2.4.12-legacy-roadcore-transplant-5m.zip`
- Base NewCore: `TerraNova-NewCore-v2.4.11-visual-ui-crossing-lanes-5m.zip`
- Referencia antiga: `simurban modular.zip`
- Escala preservada: 1 unidade de mundo = 5 metros.

## Resumo tecnico

Esta versao usa o NewCore como casca moderna e integra o comportamento principal do RoadCore antigo por adaptacao limpa, sem substituir `src/main.js`, sem colar `game.original.js` e sem converter o projeto em monolito.

O transplante ficou concentrado em um adaptador modular novo, `src/roads/LegacyRoadCore5m.js`, que replica as regras antigas de largura, centro de faixas, transicoes de pontas, rampas e trim de cruzamentos, ja convertidas para 5m/u. O renderer, mapa, terreno, clima, atmosfera e iluminacao continuam sendo do NewCore.

## Arquivos alterados

- `index.html`
- `iniciar-terra-nova-bazzite.sh`
- `iniciar-terra-nova-windows.bat`
- `package.json`
- `README.md`
- `src/game/GameState.js`
- `src/map/MapGenerator.js`
- `src/rail/RailRenderer.js`
- `src/roads/RoadIntersections.js`
- `src/roads/RoadMarkings.js`
- `src/roads/RoadRenderer.js`
- `src/systems/InputController.js`
- `src/systems/RailSystem.js`
- `src/systems/RoadSystem.js`
- `src/systems/VehicleSystem.js`
- `src/systems/ZoningSystem.js`
- `src/utils/Materials.js`
- `styles/newcore.css`
- `tools/smoke-newcore.mjs`

## Arquivos criados

- `src/roads/LegacyRoadCore5m.js`
- `relatorios/PLANO_v2.4.12_legacy_roadcore_transplant_5m.md`
- `relatorios/RELATORIO_v2.4.12_legacy_roadcore_transplant_5m.md`
- `relatorios/AUDITORIA_LEGACY_ROADCORE_TRANSPLANT_v2.4.12.md`

## Sistemas antigos integrados/adaptados

- RoadCore legado: larguras, faixas por sentido, mao unica/dupla, avenida, rua, terra, offsets laterais e centro de faixa.
- Geometria de pontas: transicoes antigas de endpoints e rampas para evitar cortes abruptos em elevado/tunel.
- Cruzamentos: trims de malha e marcacoes respeitando a geometria antiga, com render moderno do NewCore.
- Trafego: veiculos usam centro de faixa coerente com o legado e deixam de tender ao lado/contramao em vias de dois sentidos.
- Marcacoes: centro amarelo, divisorias brancas, overlays de classe de faixa e setas usam os centros de faixa do legado.
- Zoneamento: clearance recalibrado para 5m/u, evitando lote invadir via/no de cruzamento e reduzindo grids quebrados.
- Trilhos: escala, largura, sleepers, plataformas e estacoes convertidos para 5m/u; estacoes antigas sao limitadas no render para nao explodir em tamanho.
- Minimap/UI: minimapa permanece visivel na cidade mesmo em 1366px e em UI colapsada, com HUD separado do gerador.
- Launchers: Windows e Bazzite atualizados para v2.4.12 com cache-bust `v2412`.

## Sistemas ignorados de proposito

- Iluminacao antiga do jogo modular.
- Renderer antigo, sky antigo, atmosfera antiga e qualquer pipeline de luz antigo.
- Copia integral de `game.original.js`.
- Assets PNG externos obrigatorios.
- Dependencia de CDN/internet para rodar.

## Confirmacao sobre iluminacao

A iluminacao antiga NAO foi integrada. A v2.4.12 preserva a atmosfera/iluminacao propria do NewCore em `src/map/AtmosphereSystem.js` e os ajustes modernos de luz do `MapGenerator.js`. O antigo modular foi usado como referencia de comportamento, nao como fonte de renderer/sky/lighting.

## Validacao executada

Ambiente: Windows, Chrome local, runtime Node/NPM do Codex.

- `npm run check` - OK, `checked=38`.
- `npm run audit` - OK, `modules=38`, `maxModuleLines=1189`.
- `npm run smoke` - OK usando `CHROME_PATH="C:\Program Files\Google\Chrome\Application\chrome.exe"`, `PYTHON=Python313`, `PW_INDEX` do runtime Codex.
- Smoke aprovado: versao correta, sistemas nucleo presentes, vias renderizadas, predios renderizados, TMPE, painel de info, minimapa, atalhos, save/load e zero erro fatal de runtime.
- `bash -n iniciar-terra-nova-bazzite.sh` - nao executado neste Windows porque `bash` nao existe no PATH e o WSL instalado e apenas o stub sem distribuicao Linux. O script foi atualizado e revisado estaticamente.

## QA manual documentado

1. Abrir o jogo pelo launcher Windows ou Bazzite.
2. Ver tela inicial.
3. Clicar Novo mapa.
4. Gerar mapa.
5. Entrar na cidade.
6. Confirmar que a UI do gerador nao aparece misturada com a HUD da cidade.
7. Construir rua reta bidirecional.
8. Construir avenida.
9. Construir via de mao unica.
10. Construir curva.
11. Construir cruzamento T.
12. Construir cruzamento X.
13. Pintar zoneamento residencial, comercial e industrial.
14. Esperar surgirem predios.
15. Verificar frente dos predios para a rua.
16. Criar paradas de onibus.
17. Criar linha de onibus.
18. Ver onibus seguindo faixa/sentido correto.
19. Criar trilho duplo.
20. Criar estacao.
21. Criar linha ferroviaria.
22. Ver trem trafegando.
23. Testar PageUp/PageDown.
24. Criar elevado.
25. Criar tunel/nivel negativo, se suportado.
26. Testar TMPE/faixa de onibus.
27. Testar save/export JSON.
28. Recarregar save.
29. Verificar HUD: dinheiro, populacao, empregos, passageiros/h, congestionamento.
30. Conferir FPS aceitavel em 1366x768 e 1920x1080.

## Bugs conhecidos / limites

- `bash -n` nao pode ser executado neste ambiente Windows atual por falta de bash/WSL funcional.
- O smoke automatizado cobre render, HUD, painels, minimapa, zoning/buildings, TMPE e save/load, mas o QA humano ainda deve conferir rotas longas de onibus/trem e FPS real na maquina final.
- Os assets de zoneamento enviados pelo usuario nao foram usados, conforme orientacao de usar apenas como referencia visual.

## Proximos passos recomendados

- Fazer uma rodada manual focada em onibus/trem com rotas longas e cruzamentos densos.
- Capturar screenshots 1366x768 e 1920x1080 depois do launcher real.
- Evoluir o adaptador `LegacyRoadCore5m.js` para cobrir regras mais finas de prioridade/faixa se surgirem casos de contramao em saves maiores.
