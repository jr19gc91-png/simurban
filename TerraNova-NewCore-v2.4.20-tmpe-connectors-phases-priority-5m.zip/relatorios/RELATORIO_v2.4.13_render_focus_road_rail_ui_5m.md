# Terra Nova / SIMURB NewCore v2.4.13 - Render Focus Road/Rail/UI 5m/u

## Base
- Entrada: `TerraNova-NewCore-v2.4.12-legacy-roadcore-transplant-5m.zip`.
- Saída: `TerraNova-NewCore-v2.4.13-render-focus-road-rail-ui-5m.zip`.
- Escala mantida: `1 unidade = 5 metros`.

## Foco desta rodada
A rodada foi focada em renderização, não em IA ou economia.

## Correções aplicadas

### Estradas e nós
- Desativado o taper automático dos segmentos de via, que estava criando placas, triângulos e manchas nos nós.
- Segmentos de rua, avenida, mão única, terra e elevado agora renderizam como ribbons contínuas e estáveis.
- Nós de dois braços agora são tratados como continuação/curva e não recebem mais remendos visuais.
- Patches retangulares de desgaste no asfalto foram desativados porque pareciam artefatos/placas.
- Snap de construção reduzido para evitar grudar forte demais em nós/segmentos distantes.

### Cruzamentos
- Substituído o hull procedural antigo dos cruzamentos por um pad circular simples com renderOrder alto.
- O pad central agora cobre as marcações internas quebradas, evitando linhas atravessando o miolo.
- Faixas de pedestres e linhas de parada foram reduzidas e reposicionadas.
- Guias internos de aproximação foram desligados para remover marcações estranhas.
- Caixa amarela central ficou discreta e só aparece em cruzamentos grandes de 4 braços.

### Elevados e rampas
- Removidos os remendos de nó em curvas/elevados, que eram a principal origem das placas nas pontas.
- Mantidos pilares, barreiras e sombra projetada no chão.
- Rampas continuam baseadas na interpolação de altura do segmento, mas agora sem placas centrais desenhadas por cima.

### Trilhos
- Recalibrada a renderização dos trilhos para a escala 5m/u.
- Reduzidos lastro, ombro, distância entre trilhos, dormentes e largura dos metais.
- Corrigidos alguns valores brutos restantes que ainda estavam fora do helper `m()`.

### Minimapa / botões
- Botão Interface agora força o estado colapsado também por estilo inline, não só por classe CSS.
- Minimapa permanece visível quando a interface é ocultada.
- Grade do mundo agora usa `depthTest=false` e renderOrder alto, para aparecer sobre o terreno quando ativada pelo minimapa.

## Arquivos alterados
- `src/roads/RoadRenderer.js`
- `src/roads/RoadIntersections.js`
- `src/roads/RoadMarkings.js`
- `src/rail/RailRenderer.js`
- `src/systems/RailSystem.js`
- `src/systems/RoadSystem.js`
- `src/ui/Minimap.js`
- `src/game/GameShell.js`
- `styles/newcore.css`
- `src/game/GameState.js`
- `src/map/MapGenerator.js`
- `index.html`
- `README.md`
- `package.json`
- launchers Windows/Bazzite

## Validação
- `npm run check`: OK (`checked=38`).
- `npm run audit`: OK (`maxModuleLines=1189`).
- `bash -n iniciar-terra-nova-bazzite.sh`: OK.
- `npm run smoke`: não executado porque Playwright não está instalado no ambiente.

## Pendências honestas
- Ainda não é o renderer final definitivo de cruzamentos com geometria perfeita por braço/faixa; esta rodada prioriza estabilizar a renderização e remover placas/artefatos.
- Rampas seguem como interpolação visual de altura; a malha específica de rampa ainda pode ser refinada depois.
- Zoneamento não foi o foco principal desta rodada, exceto o impacto indireto do snap/grade.
