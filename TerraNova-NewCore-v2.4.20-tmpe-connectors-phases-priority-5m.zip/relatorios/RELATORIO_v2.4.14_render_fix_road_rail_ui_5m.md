# TerraNova-NewCore v2.4.14 — Render Fix Road/Rail/UI 5m/u

## Objetivo
Correção focada na renderização após QA visual em 1366×768, mantendo a escala oficial `1 unidade = 5 metros` e sem voltar para arquivo monolítico.

## Alterações principais

### Estradas e cruzamentos
- Corrigida a orientação da faixa de pedestres: a zebra agora usa tiras verticais no sentido da via, repetidas pela largura da rua, seguindo a referência brasileira enviada.
- Nó com 2 braços no nível do solo agora recebe junta curta/circular apenas quando é curva; isso cobre cortes/fatias entre segmentos sem transformar o nó em cruzamento.
- Nó elevado com 2 braços não recebe pad/placa visual, reduzindo as lajes quebradas em curvas elevadas.
- A caixa amarela do cruzamento foi ampliada para contorno + diagonais, mais próxima do padrão BR.
- Markings, medianas e overlays agora só são aparados em cruzamentos reais de 3+ braços, evitando que avenidas/curvas fiquem fatiadas em nós intermediários.
- Curvas suavizadas com menos overshoot em Hermite para reduzir cortes e trechos quebrados.

### Rampas/elevados
- Rampa visual não é mais gerada automaticamente em segmento elevado solto.
- Rampa só é gerada quando há conexão real entre níveis diferentes por nó/segmento, evitando rampas quebradas em pontas livres.

### Trilhos
- Ribbons de trilho/lastro usam `DoubleSide` e polygon offset para reduzir desaparecimento por ângulo de câmera.
- Adicionadas juntas visuais nos nós ferroviários para cobrir falhas entre segmentos.

### Zoneamento
- Profundidade visual da grade reduzida para 2 fileiras para evitar malha muito distante da via.
- Aumentada folga em nós e outras vias para diminuir sobreposição em cruzamentos.
- Opacidade da grade reduzida para poluir menos a leitura das estradas.

### Interface e grade
- Botão Interface agora recolhe topbar, barra inferior, painel lateral, painel de ferramenta, info panels e pills; mantém somente um botão mínimo para restaurar.
- Grade do mundo agora usa divisão de 1 unidade do jogo, ou seja, cada célula representa 5m.
- Limite rígido de 1200 linhas removido do audit; o audit continua bloqueando `game.js` monolítico e passa a avisar apenas módulos extremamente grandes (>2400 linhas).

## Arquivos alterados
- `src/roads/RoadIntersections.js`
- `src/roads/RoadRenderer.js`
- `src/roads/LegacyRoadCore5m.js`
- `src/systems/RoadSystem.js`
- `src/systems/ZoningSystem.js`
- `src/rail/RailGeometry.js`
- `src/rail/RailRenderer.js`
- `src/game/GameShell.js`
- `src/ui/Minimap.js`
- `styles/newcore.css`
- `tools/audit-modules.mjs`
- `index.html`
- `README.md`
- `package.json`
- launchers Windows/Bazzite

## Validação
- `npm run check` OK
- `npm run audit` OK
- `bash -n iniciar-terra-nova-bazzite.sh` OK

## Observação honesta
Essa rodada corrige renderização e regras visuais críticas, mas não substitui um teste visual real no navegador em todas as combinações de via. Se ainda houver quebra, o próximo passo deve ser capturar especificamente o tipo de segmento/nó que falhou e consolidar o renderer de nó/curva em um módulo dedicado, sem voltar ao `game.js` monolítico.
