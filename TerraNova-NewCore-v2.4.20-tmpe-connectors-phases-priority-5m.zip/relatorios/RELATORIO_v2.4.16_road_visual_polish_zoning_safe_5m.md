# TerraNova-NewCore v2.4.16 — Road Visual Polish + Zoning Safe 5m/u

Base usada: `TerraNova-NewCore-v2.4.14-render-fix-road-rail-ui-5m.zip`.

## Objetivo

Continuar a partir da v2.4.14, descartando a regressão da v2.4.15. O foco desta rodada foi refino/polimento visual das estradas e cruzamentos sem alterar o fluxo de zoneamento.

## Garantia contra regressão de zoneamento

- `src/systems/ZoningSystem.js` não foi refeito e não recebeu alteração funcional nesta rodada.
- O fluxo de pintura por `zoneGrid`, criação de lotes, `roadId`, `gridKeys`, orientação de lote e ocupação de células foi preservado.
- As mudanças ficaram concentradas em renderização visual: `RoadRenderer`, `RoadIntersections`, `RoadMarkings` e `Materials`.

## Estradas e cruzamentos

- Corrigida a orientação da faixa de pedestres zebrada: barras agora ficam transversais à pista, atravessando a largura da via, repetidas no sentido de aproximação.
- Linha de retenção reposicionada antes da faixa de pedestres, mantendo distância limpa do miolo do cruzamento.
- Adicionados guias curtos de aproximação nos cruzamentos T/+ para manter leitura de faixas sem atravessar o pad central.
- Desgaste do asfalto agora é recortado perto de nós/cruzamentos para evitar linhas sujas invadindo o miolo.
- Marcações brancas/amarelas receberam leve aumento de legibilidade sem voltar ao visual fluorescente.

## Polimento por tipo de via

- Ruas asfaltadas: sarjeta escura discreta nas bordas, asfalto ligeiramente mais claro e marcações mais limpas.
- Avenidas: canteiro central refinado com meio-fio e árvores modulares leves em segmentos longos no nível do solo.
- Ruas de terra: ombros laterais e marcas de rodagem discretas, mantendo terra sem calçada/zoneamento.
- Vias zoneáveis: calçadas recebem juntas sutis para melhor leitura urbana sem poluir a UI visual.

## Arquivos alterados

- `src/roads/RoadIntersections.js`
- `src/roads/RoadRenderer.js`
- `src/roads/RoadMarkings.js`
- `src/utils/Materials.js`
- `README.md`
- `index.html`
- `package.json`
- `src/game/GameState.js`
- `src/map/MapGenerator.js`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`

## Validação executada

- `npm run check` — OK, 38 arquivos JS parseados sem erro.
- `npm run audit` — OK, 38 módulos, maior módulo com 1189 linhas, sem `game.js` monolítico.
- `npm run smoke` — não executado neste ambiente porque o Playwright não está instalado; o script retornou status 2 informando dependência ausente.

## Observação

A v2.4.16 deve substituir a v2.4.15 como continuação segura da v2.4.14. Esta rodada não mexe no RoadCore nem no `ZoningSystem`, justamente para evitar repetir a quebra de zoneamento.
