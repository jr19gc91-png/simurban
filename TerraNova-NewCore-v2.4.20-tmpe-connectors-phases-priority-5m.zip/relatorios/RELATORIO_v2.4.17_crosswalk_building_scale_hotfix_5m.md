# TerraNova-NewCore v2.4.17 — Crosswalk + Building Scale Hotfix 5m/u

## Base

- Base de trabalho: `TerraNova-NewCore-v2.4.16-road-visual-polish-zoning-safe-5m`, derivada da v2.4.14 segura.
- A v2.4.15 continua descartada por regressão de zoneamento.
- `ZoningSystem.js` não foi refeito e não teve fluxo de pintura/geração de lotes alterado nesta rodada.

## Correções principais

### 1. Faixa de pedestres / cruzamentos

Arquivo: `src/roads/RoadIntersections.js`

- Refeito o layout de zebra dos cruzamentos.
- Barras da faixa agora são compridas no sentido da travessia do pedestre e estreitas no sentido do tráfego.
- Crosswalk usa layout único por aproximação, considerando raio real do cruzamento.
- Linha de retenção foi reposicionada para ficar antes da zebra, sem invadir a travessia.
- Guias de aproximação das faixas agora começam depois da zebra/linha de retenção, evitando poluição visual.
- A caixa amarela central ficou mais fina para reduzir ruído no miolo do cruzamento.

Arquivo: `src/roads/LegacyRoadCore5m.js`

- Afastamento das marcações viárias em nós foi ampliado para cortar pintura antes da travessia.
- Superfície da via não foi alterada; o ajuste é focado em pintura/overlays.

### 2. Escala das construções

Arquivo: `src/systems/BuildingSystem.js`

- Corrigida a conversão de medidas fixas para a escala 1 unidade = 5 m.
- Reduzida ocupação de footprint: prédios deixam de ocupar quase 100% do lote.
- Alturas reajustadas por zona/densidade em metros reais convertidos por `m()`.
- Portas, janelas, telhados, muros, antenas, caixas d’água, toldos, sacadas, props industriais e detalhes de fachada foram redimensionados.
- Adicionada migração visual para construções antigas já salvas: ao renderizar, prédios sem `scaleVersion: '2.4.17'` são recalculados com a nova escala.

## Validação

- `npm run check`: passou, 38 arquivos JS conferidos.
- `npm run audit`: passou, sem módulo acima do limite atual.
- `npm run smoke`: não executado no ambiente local porque Playwright não está instalado.

## Observação

Esta rodada foi deliberadamente cirúrgica: cruzamentos/faixas + escala visual das construções. Não houve reescrita de RoadCore, UI, zoneamento ou simulação.
