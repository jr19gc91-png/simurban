# RELATORIO v2.4.1 - Legacy Parity Lighting/Tools Hotfix

## Resumo

Esta rodada corrige pontos em que o NewCore v2.4.0 ainda estava distante do SIMURB modular antigo: iluminacao escura, ceu/atmosfera basicos, submenus de ferramentas incompletos, modo Sandbox/Simulacao, zoneamento quebrado em cruzamentos, marcacoes viarias atravessando nos e animacoes lentas.

O renderer moderno do NewCore foi preservado. A iluminacao antiga NAO foi integrada.

## Arquivos alterados

- `index.html`
- `README.md`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`
- `styles/newcore.css`
- `src/map/AtmosphereSystem.js`
- `src/map/MapGenerator.js`
- `src/utils/GameBalance.js`
- `src/game/GameState.js`
- `src/game/GameShell.js`
- `src/systems/RoadSystem.js`
- `src/systems/ZoningSystem.js`
- `src/systems/VehicleSystem.js`
- `src/roads/RoadMarkings.js`
- `src/ui/UISystem.js`

## Arquivos criados

- `relatorios/RELATORIO_v2.4.1_legacy_parity_lighting_tools_hotfix.md`
- `relatorios/AUDITORIA_LEGACY_PARITY_LIGHTING_TOOLS_v2.4.1.md`

## Sistemas antigos integrados/adaptados

- Modo Sandbox/Simulacao com regra real para trafego de teste.
- Presets antigos de estradas: terra, rua local, rua 2 faixas, avenida, mao unica, expressa, corredor bus, elevado e tunel.
- Opcoes antigas de construcao: snap, zoneamento de borda, lados de zona, tipo R/C/I associado a via, estacionamento e faixa/corredor de onibus.
- Barra de velocidade 1x/2x/3x/4x/5x.
- Dia de jogo mantido em 30 minutos reais no 1x.
- Movimento visual de veiculos acelerado por `vehicleMotionScale`, sem acelerar o calendario base.
- Grade de zona respeitando lados da via e folga maior em nos/cruzamentos.
- Marcacoes de faixa recortadas antes do miolo do cruzamento.

## Sistemas ignorados ou nao transplantados

- Iluminacao, sky, fog e atmosfera do jogo antigo.
- Assets externos do ZIP de assets de zoneamento. Foram usados apenas como referencia visual solicitada.
- Monolito `game.js` antigo.

## Iluminacao

Confirmacao explicita: a iluminacao antiga NAO foi integrada. A v2.4.1 usa `src/map/AtmosphereSystem.js` proprio do NewCore, com ceu procedural seguindo a camera, sol/lua visiveis, nuvens/chuva, fog mais claro e exposicao diurna reforcada.

## Validacao executada

- `C:\Users\User\AppData\Local\OpenAI\Codex\bin\5b9024f90663758b\node.exe tools\check-js.mjs`
  - Resultado: `checked=36`
- `C:\Users\User\AppData\Local\OpenAI\Codex\bin\5b9024f90663758b\node.exe tools\audit-modules.mjs`
  - Resultado: `modules=36`, maior modulo `src/systems/RoadSystem.js` com 1160 linhas.
- Browser smoke local em `http://127.0.0.1:8131/?cache=v241-browser-smoke-2`
  - Tela inicial visivel.
  - Gerador visivel e HUD da cidade oculto.
  - Cidade visivel com HUD e gerador oculto.
  - Canvas validado em 1366x768.
  - Painel de estradas abriu com 9 presets, 4 toggles antigos, lados de zona e velocidades 1/2/3/4/5.
  - Alternancia Sandbox -> Simulacao validada.
  - Console fatal: nenhum erro.

## Validacao nao executada automaticamente

- `tools/smoke-newcore.mjs`: nao executou porque Playwright nao esta instalado no projeto.
- Viewport automatizado 1920x1080 pelo navegador embutido: a conexao da ferramenta caiu ao aplicar override grande; nao houve erro fatal capturado do jogo antes da queda. Manter como QA manual recomendado.
- `bash -n iniciar-terra-nova-bazzite.sh`: nao executado neste Windows porque `bash` nao esta no PATH e o WSL instalado nao possui distribuicao configurada para rodar bash.

## Bugs conhecidos

- A paridade com o jogo antigo ainda nao e total em ferramentas avancadas de transporte/RCI; esta rodada focou nos defeitos visiveis e nos controles antigos mais importantes.
- O teste automatico em 1920x1080 precisa de Playwright instalado ou execucao manual.

## QA manual recomendado

1. Abrir pelo launcher Windows ou Bazzite.
2. Ver tela inicial.
3. Clicar Novo mapa, gerar mapa e entrar na cidade.
4. Confirmar que gerador e HUD da cidade nao aparecem misturados.
5. Construir rua, avenida, mao unica, curva, T e X.
6. Alternar presets expressa, corredor bus, elevado e tunel.
7. Pintar residencial/comercial/industrial e aguardar predios.
8. Conferir lotes sem invadir cruzamentos e frente dos predios para a rua.
9. Criar paradas, linhas de onibus, trilho duplo, estacao e linha ferroviaria.
10. Conferir veiculos sem contramao e respeitando faixas basicas.
11. Testar PageUp/PageDown.
12. Testar TMPE/classes de faixa.
13. Salvar/exportar JSON e recarregar.
14. Conferir HUD: dinheiro, populacao, empregos, passageiros/h, congestionamento.
15. Conferir FPS e layout em 1366x768 e 1920x1080.

## Proximos passos

- Instalar Playwright no projeto para smoke automatizado completo.
- Completar paridade fina de submenus de transporte/terreno/economia do antigo.
- Adicionar teste automatizado de construcao T/X + pintura de zona + veiculo em rota.
