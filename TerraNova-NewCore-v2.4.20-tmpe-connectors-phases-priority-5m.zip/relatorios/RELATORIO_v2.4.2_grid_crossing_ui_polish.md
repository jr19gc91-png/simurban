# RELATORIO v2.4.2 - Grid/Crossing/UI Polish

## Resumo

Rodada aplicada sobre `TerraNova-NewCore-v2.4.1-legacy-parity-lighting-tools-hotfix.zip`.

Foco: corrigir o desalinhamento da grade de zoneamento com as ruas, reduzir a quebra visual nos cruzamentos e deixar os submenus de ferramentas menos técnicos e mais jogáveis.

## Arquivos alterados

- `index.html`
- `README.md`
- `package.json`
- `iniciar-terra-nova-windows.bat`
- `iniciar-terra-nova-bazzite.sh`
- `styles/newcore.css`
- `src/game/GameShell.js`
- `src/game/GameState.js`
- `src/roads/RoadIntersections.js`
- `src/systems/ZoningSystem.js`
- `src/ui/UISystem.js`

## Correções feitas

### Grade de zoneamento

- Refeita a geração da grade para usar coordenadas locais do segmento da via, com colunas/linhas por `roadId`, `side`, `row` e `col`.
- Removida a dependência da chave global arredondada em coordenadas do mundo, que criava lotes em escadinha, deslocados ou com buracos em diagonais/curvas.
- Primeira fileira agora respeita uma folga de calçada e não é bloqueada falsamente pela própria via.
- A ocupação/zoneamento de células antigas tenta ser preservada por chave local e por proximidade.
- Lotes criados agora salvam `col`, além de `row`, para manter vínculo com a nova grade.

### Cruzamentos

- T/X e curvas deixam de usar flares retangulares grandes no miolo.
- Novo pad radial por braços da interseção, ordenado angularmente, para fechar microfrestas sem criar blocos quadrados.
- Nós com apenas duas conexões só usam costura simples quando realmente são continuação quase reta; curvas de 90° passam a receber pad de junção.
- Interseções por nível continuam separadas, preservando elevado/túnel.

### Submenus de ferramentas

- Submenus deixam de ser faixa minúscula horizontal e viram cards maiores, com grid responsivo acima da barra inferior.
- Textos trocados para linguagem mais jogável: Via, Faixas, Desenho, Fluxo/altura, Extras e Lotes gerados.
- Presets de via receberam leitura visual melhor e ícones.
- Presets de estrada e trilho agora recebem estado `active` na UI.
- O cabeçalho do submenu voltou a aparecer quando há ferramenta ativa.

### Extra corrigido

- Corrigido `togglePause()`, que alternava o estado duas vezes e acabava não pausando/retomando corretamente.
- Versionamento atualizado para `v2.4.2` e cache-bust dos launchers para `v242`.

## Validação executada

- `node tools/check-js.mjs`
  - Resultado: `checked=36`
- `node tools/audit-modules.mjs`
  - Resultado: `modules=36`, maior módulo `src/systems/RoadSystem.js` com `1160` linhas.
- `bash -n iniciar-terra-nova-bazzite.sh`
  - Resultado: sem erro de sintaxe.

## Validação limitada

- O smoke visual com Playwright/Chromium não pôde ser concluído neste ambiente porque a navegação local para `127.0.0.1` foi bloqueada pelo runtime (`net::ERR_BLOCKED_BY_ADMINISTRATOR`).
- A correção foi validada por parse JS, auditoria modular e revisão estática dos pontos alterados.

## QA manual recomendado

1. Abrir pelo `.bat` ou `.sh`.
2. Entrar direto na cidade.
3. Construir rua reta, diagonal, curva, T e X.
4. Conferir se a grade de zoneamento fica paralela/ortogonal à rua, sem escadinha fora do eixo.
5. Pintar residencial/comercial/industrial e conferir frente dos lotes para a via.
6. Conferir cruzamentos T/X com avenida, rua local, mão única e curva.
7. Abrir Estradas, Trilhos, Transporte, Zoneamento, Editar via e TMPE em 1366×768.
8. Testar Pausar/Retomar.
