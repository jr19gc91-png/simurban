# RELATORIO v2.4.4 - UI / Zoning / Vehicle Terrain Polish

## Ajustes desta rodada
- UI da ferramenta de estradas compactada e com rótulos curtos/ícones.
- Zoneamento com densidades baixa/média/alta para residencial e comercial; industrial segue sem densidade.
- Grid de zoneamento reduzido e aproximado da via; calçada/recuo menor.
- Lotes maiores consumindo mais células, com predomínio de ocupações mais largas/profundas.
- Construções maiores, mais altas conforme densidade e com mais detalhes de fachada (toldos e ar-condicionado).
- Iluminação global ajustada para visual mais cinematográfico.
- Sinalização de cruzamentos reforçada: faixa de pedestres, faixa de parada e semáforos mais legíveis.
- Veículos corrigidos para inclinar no eixo correto e seguir melhor o relevo/altimetria da via.

## Arquivos alterados
- index.html
- styles/newcore.css
- src/game/GameState.js
- src/game/GameShell.js
- src/ui/UISystem.js
- src/systems/ZoningSystem.js
- src/systems/BuildingSystem.js
- src/systems/VehicleSystem.js
- src/map/AtmosphereSystem.js
- src/map/MapGenerator.js
- src/roads/RoadIntersections.js
- iniciar-terra-nova-windows.bat
- iniciar-terra-nova-bazzite.sh
- README.md

## Validação rápida
- Arquivos principais verificados com `node --check` sem erro de sintaxe.
- Compatível com a base NewCore v2.4.3, elevando schema/UI para v2.4.4.
