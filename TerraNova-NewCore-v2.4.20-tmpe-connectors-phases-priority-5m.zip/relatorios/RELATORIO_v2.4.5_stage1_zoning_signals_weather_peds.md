# Terra Nova / NewCore v2.4.5 — Etapa 1

## Escopo desta etapa
Rodada focada nas correções visuais e funcionais mais urgentes reportadas no QA da v2.4.4, priorizando:
- grade de zoneamento;
- cruzamentos / sinalização;
- regeneração limpa do mapa;
- chuva / superfícies molhadas;
- pedestres procedurais;
- refinamento de construções.

## Correções implementadas

### 1) Zoneamento
- Grade aproximada da calçada:
  - `ZONE_CELL_SIZE` reduzido;
  - `roadOffset` dos perfis reduzido;
  - `sidewalkClearanceFor()` encurtado.
- Grade/overlay de zoneamento agora só fica visível com ferramenta **Estradas** ou **Zoneamento** ativa.
- Grade passa a exibir prévia por cor de zoneamento:
  - verde = residencial;
  - azul = comercial;
  - amarelo = industrial.

### 2) Cruzamentos / semáforos / render de via
- Semáforos reposicionados/orientados para encarar melhor o fluxo de aproximação.
- Marcações de aproximação do cruzamento simplificadas para reduzir poluição visual.
- Costuras nos nós com segmentos de larguras diferentes ajustadas para reduzir “blocos” largos e melhorar a transição visual.
- Patch central do cruzamento levemente reduzido para ficar menos confuso.

### 3) Construções
- Telhados recalibrados para evitar efeito “chapéu”.
- Adicionada sombra de contato/fake AO sob as construções.
- Janelas e vidros passam a reagir melhor ao período noturno (emissivo mais quente à noite).
- Mais pequenos props/loteamentos simples adicionados em residenciais, comerciais e industriais.
- Ao renderizar construções, obstáculos naturais próximos (árvores/rochas) são limpos automaticamente da área do lote.

### 4) Chuva / wet look
- Estradas, base viária, calçadas e barreiras recebem ajuste dinâmico de roughness/metalness/cor durante chuva.
- Materiais de construções recebem resposta de superfície molhada.
- Veículos também recebem ajuste simples de wetness.
- O gerador expõe agora o estado atual do clima para os sistemas visuais.

### 5) Pedestres procedurais
- Adicionado pool de rotas peatonais usando vias zoneáveis ao nível do solo.
- Pedestres procedurais simples passam a circular pelas calçadas.
- Mantidos como elementos leves / decorativos nesta etapa.

### 6) Gerador de mapa
- Ao usar **Gerar / Seed / Reset** com a cidade aberta, a cidade é limpa antes da regeneração do terreno.
- Corrige o problema do “novo mapa” manter a cidade anterior em cima do relevo recém-gerado.

## Arquivos principais alterados
- `index.html`
- `src/game/GameShell.js`
- `src/game/GameState.js`
- `src/map/MapGenerator.js`
- `src/roads/RoadIntersections.js`
- `src/systems/RoadSystem.js`
- `src/systems/ZoningSystem.js`
- `src/systems/BuildingSystem.js`
- `src/systems/VehicleSystem.js`
- `src/ui/UISystem.js`

## Validação executada
- Parse sintático via `node --check` nos arquivos alterados.
- ZIP final gerado com relatório incluso.

## Pendências para próxima etapa
### Etapa 2 sugerida
1. afunilamento geométrico mais sofisticado entre larguras de via;
2. ferramental de terreno em paridade maior com o modo antigo (pincéis / texturas / árvores / terraform);
3. chuva mais avançada (poças/splashes);
4. refinamento adicional de cruzamentos complexos e vias elevadas/túneis.

