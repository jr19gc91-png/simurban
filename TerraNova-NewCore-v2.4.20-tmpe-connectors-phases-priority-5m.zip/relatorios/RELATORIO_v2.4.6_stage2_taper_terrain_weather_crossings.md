# Terra Nova / NewCore v2.4.6 — Etapa 2

## Foco
Etapa 2 iniciada em cima da v2.4.5, com correções cirúrgicas em:
- afunilamento visual entre vias de larguras diferentes;
- ferramenta de terreno mais parecida com o modo antigo;
- chuva / superfícies molhadas;
- cruzamentos complexos menos poluídos.

## Implementado

### 1) Afunilamento entre estradas de larguras diferentes
- `RoadRenderer` ganhou `buildTaperedRibbon()`.
- Superfície e base das vias agora ajustam largura perto dos nós quando há conexão com via mais estreita/larga.
- A transição é suave nos primeiros/últimos metros do segmento para reduzir cortes secos entre ruas/avenidas.

### 2) Cruzamentos menos confusos
- Marcações de aproximação em cruzamentos grandes foram encurtadas.
- Faixas de pedestres ficaram mais contidas.
- Linhas de parada ficaram menores e menos agressivas.
- Patch central do cruzamento foi reduzido para diminuir sobreposição visual.

### 3) Ferramenta de terreno
- A ferramenta de terreno agora tem pincéis rápidos:
  - Árvores;
  - Rochas;
  - Grama;
  - Terra;
  - Cascalho;
  - Limpar;
  - Nivelar visual;
  - Aterrar visual;
  - Rebaixar visual.
- Clique/arrasto aplica o pincel direto no mapa.
- O gerador expõe APIs públicas para adicionar árvores, rochas e manchas de terreno no mapa atual.
- A limpeza remove árvores/rochas dentro da área do pincel.

### 4) Chuva / wet look
- Sistema visual de chuva foi reforçado com mais gotas e maior opacidade.
- RoadSystem já ajusta roughness/metalness/cor de asfalto/calçada/barreiras conforme chuva.
- BuildingSystem e VehicleSystem mantêm resposta visual de molhado sem acumular alteração infinita nos materiais.

### 5) Versão / launchers
- Schema atualizado para `newcore-save-v2.4.6`.
- `NEWCORE_VERSION` atualizado para `TerraNova-NewCore-v2.4.6-stage2-taper-terrain-weather-crossings`.
- Launchers Windows/Bazzite atualizados com cache-bust `v246`.

## Validação executada
- `node --check` nos arquivos alterados.
- `node tools/check-js.mjs` → `checked=36`.
- `node tools/audit-modules.mjs` → OK; maior módulo com 1183 linhas.
- `bash -n iniciar-terra-nova-bazzite.sh` → OK.

## Observações honestas
- O terraforming físico real do heightmap ainda não foi implementado. Os pincéis `nivelar/aterrar/rebaixar` são visuais nesta etapa.
- O afunilamento já existe na base/superfície da via, mas marcações/faixas internas ainda podem precisar de uma etapa dedicada para acompanhar 100% a largura variável.

## Próxima etapa sugerida
- Fazer afunilamento também nas marcações/faixas/calçadas.
- Implementar terraforming real alterando malha/heightmap do terreno.
- Adicionar poças e respingos de pneus/pedestres.
- Revisar cruzamentos T/X com avenida + rua local + elevado.
