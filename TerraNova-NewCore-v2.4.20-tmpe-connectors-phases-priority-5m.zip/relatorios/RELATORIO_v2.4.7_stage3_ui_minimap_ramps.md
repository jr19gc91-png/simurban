# Terra Nova / NewCore v2.4.7 — Stage 3 UI, minimapa, ramps e cruzamentos

## Objetivo desta rodada
Aplicar a etapa 3 pedida em QA visual/funcional, focando em:
- UI das ferramentas sem rolagem e com botões maiores
- ferramenta de estradas simplificada (terra, rua bidirecional, avenida bidirecional, mão única)
- minimapa no canto direito com grade e ocultar interface
- mover “Editar via” para dentro do fluxo do TMPE
- remover botões Salvar / Carregar / Gerador da barra inferior
- melhorar cruzamentos (faixa de pedestres + linha de parada)
- acelerar animação dos veículos
- reduzir sobreposição de zoneamento em cruzamentos
- criar ramps visuais em elevados
- ampliar escala visual dos mapas

## Arquivos alterados
- `index.html`
- `styles/newcore.css`
- `src/ui/UISystem.js`
- `src/ui/Minimap.js`
- `src/utils/GameBalance.js`
- `src/map/MapGenerator.js`
- `src/systems/ZoningSystem.js`
- `src/roads/RoadIntersections.js`
- `src/systems/RoadSystem.js`

## Alterações implementadas

### 1) Ferramenta de estradas simplificada
A UI da ferramenta de vias agora foi reduzida para o conjunto pedido:
- rua de terra
- rua bidirecional
- avenida bidirecional
- mão única

Mantidos no mesmo painel, sem submenu longo:
- número de faixas (1 a 5)
- velocidade
- desenho (curva/reta)
- fluxo
- nível da via (solo/elevado/túnel)
- snap
- zoneamento ON/OFF
- estacionamento ON/OFF
- lado zoneável

Também foram removidas abreviações mais agressivas e os botões ficaram maiores.

### 2) UI sem rolagem e botões maiores
No modo cidade, a barra inferior e o painel de ferramentas receberam overrides finais para:
- textos mais legíveis
- botões com largura maior
- labels visíveis
- painel de ferramentas compacto em grade, sem depender de barra de rolagem no desktop

### 3) Ordem das ferramentas na barra inferior
A ferramenta **Inspecionar** agora fica antes de **Estradas**, como pedido.

### 4) TMPE incorporando “Editar via”
O botão da barra inferior para **Editar via** foi removido.
O acesso agora entra pelo TMPE através do botão **🧭 Editar via** dentro do painel do gestor de tráfego.

### 5) Minimapa no canto direito
O minimapa agora fica no lado direito inferior e ganhou dock com:
- **Interface** (mostrar/ocultar HUD e barras)
- **Grade**
- **Edifícios**
- **Veículos**

Os botões **Salvar / Carregar / Gerador** foram retirados da barra inferior. O acesso a salvar/carregar continua disponível pelo menu hambúrguer.

### 6) Cruzamentos
A renderização de cruzamentos foi ajustada para ficar mais próxima da referência enviada:
- faixas de pedestres mais largas e regulares
- maior quantidade de listras de zebra
- linha de parada redesenhada e reposicionada antes da travessia
- semáforos reposicionados para leitura melhor do cruzamento

### 7) Zoneamento em cruzamentos
Foi aumentada a folga para geração de grade/lotes perto de nós e de outras vias, reduzindo a sobreposição visual das células zoneáveis em interseções.

### 8) Animação / velocidade do jogo
Foi acelerado o movimento visual dos veículos, elevando `vehicleMotionScale` de `1.75` para `2.65`.
Isso melhora a sensação de fluxo sem alterar a lógica geral do HUD.

### 9) Mapas visualmente maiores
A base de escala do gerador foi ampliada de `2400` para `3000`, aumentando a sensação espacial dos mapas 10×10 / 20×20 / 30×30 km.

> Observação: isso melhora a percepção do tamanho e a área utilizável no mundo renderizado, mas não reescreve toda a malha/simulação para 1 unidade = 1 metro real.

### 10) Elevados com rampas
Foi adicionado easing vertical nas extremidades de segmentos elevados sem continuação no mesmo nível, criando ramps visuais automáticas de acesso/saída do elevado.

## Validação executada
- `npm run check` ✅
  - `checked=36`
- `npm run audit` ⚠️
  - código parseado normalmente
  - o auditor ainda acusa `src/systems/RoadSystem.js` acima de 1200 linhas (`1205`), já muito próximo do limite e herdado da base atual
- `npm run smoke` ⚠️ não executado
  - Playwright não instalado no ambiente

## Pendências / observações
- O auditor modular ainda reclama de `RoadSystem.js` por **5 linhas** acima do teto interno de 1200.
- A parte de ramps foi tratada no render/sampling da via; se quiser, a próxima rodada pode aprofundar em ramps com lógica mais explícita de conexão solo↔elevado.
- Se ainda houver algum “plate” residual em nós elevados, a próxima rodada ideal é atacar diretamente a geometria de junção/taper dos nós elevados.

## Pacote desta rodada
`TerraNova-NewCore-v2.4.7-stage3-ui-minimap-ramps.zip`
