# Terra Nova / NewCore v2.4.8 — Stage 4 Visual UI/Crossing Fix

## Escopo
Esta etapa iniciou pelas correções visuais apontadas no QA da v2.4.7. Não tenta resolver ainda toda a lógica pesada de tráfego/faixas/motos/afunilamento; isso ficou separado para próximas etapas.

## Correções aplicadas agora

### UI / HUD
- Minimapa forçado no canto inferior direito em modo cidade.
- Minimapa com botões: Interface, Grade, Edifícios, Veículos.
- Botões de pausa/ciclo/velocidade reduzidos.
- Velocidades visíveis reduzidas para 1×, 3× e 5×.
- Painel da ferramenta de estradas ampliado horizontalmente e sem corte no desktop.
- Painel de estradas organizado em 4 colunas para caber sem barra de rolagem.

### Estradas — visual inicial
- Rua de terra agora usa geometria suave por padrão, aceitando curva.
- Rua de terra deixa de renderizar marcações/faixas/asfalto por cima; fica como via simples de terra.
- Mantidos controles principais: tipo de via, faixas, velocidade, desenho, fluxo, nível, snap, zoneamento e estacionamento.

### Cruzamentos — visual inicial
- Faixas de pedestres reposicionadas para fora do miolo do cruzamento.
- Listras da faixa de pedestres reduzidas e mais próximas do padrão brasileiro.
- Linha de parada reposicionada antes da faixa de pedestres.
- Semáforos reposicionados para acompanhar o novo afastamento da travessia.

### Zoneamento — visual inicial
- Profundidade da grade reduzida.
- Distância mínima de zoneamento em nós/cantos aumentada para diminuir sobreposição em cruzamentos.
- Distância de conflito com vias próximas aumentada.

### Versão / cache
- Atualizado para `v2.4.8`.
- Cache bust atualizado para `v=2.4.8`.

## Dimensão real atual dos mapas
O gerador ainda não está em escala real 1 unidade = 1 metro para os labels 10/20/30 km.

Com a escala atual do código (`BASE_WORLD = 3000`, usando 20 km como base), as dimensões renderizadas são:
- botão 10×10 km: `1500 × 1500` unidades de mundo
- botão 20×20 km: `3000 × 3000` unidades de mundo
- botão 30×30 km: `4500 × 4500` unidades de mundo

Se lermos 1 unidade como 1 metro, isso equivale a aproximadamente:
- 1,5 × 1,5 km
- 3,0 × 3,0 km
- 4,5 × 4,5 km

Ou seja: os labels 10/20/30 km ainda são conceituais, não escala física real.

## Validação
- `npm run check` executado com sucesso.
- Resultado: `checked=36`.

## Próximas etapas sugeridas
1. Corrigir centro de faixa dos veículos e path/lane real.
2. Adicionar motos e corredor.
3. Refazer geometria de avenida/mão única/terra com regras próprias.
4. Afunilamento funcional real entre larguras diferentes.
5. Escala real do mapa com LOD/chunking para 10/20/30 km verdadeiros.
