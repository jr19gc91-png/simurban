# RELATORIO v2.4.9 — escala oficial 1 unidade = 5 metros

## Decisão aplicada
A escala oficial do NewCore foi alterada para:

- **1 unidade de mundo = 5 metros reais**
- **1 metro = 0,2 unidade**
- **1 km = 200 unidades**

## Dimensões reais dos mapas
Agora os botões do gerador ficam assim:

| Opção | Mundo em unidades | Equivalente real |
|---|---:|---:|
| 10×10 km | 2000 × 2000 u | 10.000 × 10.000 m |
| 20×20 km | 4000 × 4000 u | 20.000 × 20.000 m |
| 30×30 km | 6000 × 6000 u | 30.000 × 30.000 m |

Antes a escala estava em ~6,67 m/u e o mapa 20 km tinha 3000 unidades. Agora o mapa 20 km tem 4000 unidades, batendo com a escala 5m/u.

## Arquivo novo
- `src/utils/Scale.js`

Centraliza:
- `METERS_PER_UNIT = 5`
- `UNITS_PER_METER = 0.2`
- `m(valorEmMetros)`
- `meters(valorEmUnidades)`
- `kmToWorldUnits(km)`

## Sistemas ajustados
### Mapa
- `MapGenerator.js`
  - `WORLD = kmToWorldUnits(km)`
  - `getStats()` agora expõe `metersPerUnit` e `worldKm`
  - pill de status mostra `1u=5m`

### Vias
- `RoadSystem.js`
  - larguras de ruas, avenidas, rua de terra, medianas, calçadas e offsets principais convertidos com `m()`
  - distância de snap/seleção recalibrada para escala compacta
  - altura de elevado convertida para escala 5m/u

### Render de vias
- `RoadMaterials.js`
- `RoadRenderer.js`
- `RoadMarkings.js`
- `RoadIntersections.js`

Ajustes principais:
- marcações, tracejados, faixas, canteiro e acostamento convertidos para unidades de 5m
- cruzamentos e semáforos convertidos para a nova escala
- elementos pequenos mantêm mínimo visual para não sumirem

### Zoneamento
- `ZoningSystem.js`
  - grid, lote, profundidade, distância de via e distância de cruzamento convertidos para 5m/u
  - lotes continuam representando medidas reais, mas renderizados em unidades compactas

### Construções
- `BuildingSystem.js`
  - footprint das construções convertido para unidade 5m/u
  - altura convertida via `m()`
  - capacidade populacional/empregos usa área física convertida de volta para m²

### Veículos
- `VehicleSystem.js`
  - modelos escalados para 5m/u
  - distância de deslocamento usa `UNITS_PER_METER`
  - lateral/faixa usa centro real da faixa
  - offsets de trem, pedestre e veículo ajustados

### Balanceamento
- `GameBalance.js`
  - `vehicleMotionScale` ajustado para `5.0` para compensar a escala compacta e não deixar o fluxo visual lento demais

## Validação
- `npm run check` ✅
  - `checked=37`
- `npm run audit` ✅
  - maior módulo: `RoadSystem.js` com 1194 linhas, abaixo do limite de 1200
- `bash -n iniciar-terra-nova-bazzite.sh` ✅

## Observação honesta
Essa rodada corrige a **escala estrutural** para 5m/u. Ainda vale QA visual no Chrome para calibrar fino:
- espessura de faixa/linha em zoom distante
- tamanho visual dos veículos
- tamanho dos semáforos
- legibilidade dos cruzamentos
- densidade de árvores/rochas em mapa 30×30 km
